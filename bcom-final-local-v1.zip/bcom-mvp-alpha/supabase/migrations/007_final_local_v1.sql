-- B-COM Final Local v1
-- Self registration, support, leads, blog, package entitlements and ready-made theme metadata.

alter table public.packages
  add column if not exists tier text,
  add column if not exists purchase_mode text not null default 'direct',
  add column if not exists cta_label text,
  add column if not exists contact_whatsapp text,
  add column if not exists entitlements_json jsonb not null default '{}'::jsonb,
  add column if not exists badge text;

alter table public.themes
  add column if not exists is_premium boolean not null default false,
  add column if not exists is_featured boolean not null default false,
  add column if not exists family text,
  add column if not exists preview_image_url text,
  add column if not exists demo_url text,
  add column if not exists presets_json jsonb not null default '[]'::jsonb,
  add column if not exists default_content_json jsonb not null default '{}'::jsonb;

create table if not exists public.blog_categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists public.blog_posts (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.blog_categories(id) on delete set null,
  author_id uuid references public.profiles(id) on delete set null,
  title text not null,
  slug text not null unique,
  excerpt text,
  content text not null default '',
  featured_image_url text,
  status text not null default 'draft' check(status in ('draft','published','scheduled')),
  published_at timestamptz,
  scheduled_at timestamptz,
  seo_title text,
  meta_description text,
  og_image_url text,
  canonical_url text,
  language text not null default 'id',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.contact_leads (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  company text,
  email text not null,
  phone text,
  service text,
  package_id uuid references public.packages(id) on delete set null,
  budget_range text,
  message text not null,
  source text not null default 'website',
  status text not null default 'new' check(status in ('new','contacted','qualified','quotation','negotiation','won','lost')),
  assigned_to uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  ticket_number text not null unique,
  created_by uuid not null references public.profiles(id) on delete cascade,
  tenant_id uuid references public.tenants(id) on delete set null,
  website_id uuid references public.websites(id) on delete set null,
  assigned_to uuid references public.profiles(id) on delete set null,
  category text not null default 'other',
  priority text not null default 'normal' check(priority in ('low','normal','high','urgent')),
  subject text not null,
  description text not null,
  status text not null default 'open' check(status in ('open','assigned','in_progress','waiting_customer','resolved','closed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.support_ticket_messages (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null references public.support_tickets(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  message text not null,
  is_internal boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  message text not null,
  type text not null default 'info',
  href text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.blog_categories enable row level security;
alter table public.blog_posts enable row level security;
alter table public.contact_leads enable row level security;
alter table public.support_tickets enable row level security;
alter table public.support_ticket_messages enable row level security;
alter table public.notifications enable row level security;

create policy "blog categories public read" on public.blog_categories for select using(true);
create policy "blog categories admin write" on public.blog_categories for all using(public.is_platform_admin()) with check(public.is_platform_admin());
create policy "blog published public read" on public.blog_posts for select using(status='published' or public.is_platform_admin());
create policy "blog admin write" on public.blog_posts for all using(public.is_platform_admin()) with check(public.is_platform_admin());
create policy "leads public insert" on public.contact_leads for insert with check(true);
create policy "leads admin read" on public.contact_leads for select using(public.is_platform_admin());
create policy "leads admin update" on public.contact_leads for update using(public.is_platform_admin()) with check(public.is_platform_admin());

create policy "tickets owner read" on public.support_tickets for select using(
  public.is_platform_admin() or created_by = public.current_profile_id() or (tenant_id is not null and public.is_tenant_member(tenant_id))
);
create policy "tickets owner insert" on public.support_tickets for insert with check(created_by = public.current_profile_id());
create policy "tickets admin update" on public.support_tickets for update using(public.is_platform_admin()) with check(public.is_platform_admin());
create policy "ticket messages read" on public.support_ticket_messages for select using(
  exists(select 1 from public.support_tickets t where t.id=ticket_id and (public.is_platform_admin() or t.created_by=public.current_profile_id() or (t.tenant_id is not null and public.is_tenant_member(t.tenant_id))))
);
create policy "ticket messages insert" on public.support_ticket_messages for insert with check(sender_id=public.current_profile_id() or public.is_platform_admin());
create policy "notifications own" on public.notifications for select using(user_id=public.current_profile_id() or public.is_platform_admin());
create policy "notifications own update" on public.notifications for update using(user_id=public.current_profile_id()) with check(user_id=public.current_profile_id());

insert into public.blog_categories(name,slug) values
('Website','website'),('Business','business'),('SEO','seo'),('Technology','technology')
on conflict(slug) do nothing;

-- Platform RBAC permissions
insert into public.permissions(code,name,module,description) values
('customer.view','View customers','customers','View customer list and detail'),
('customer.manage','Manage customers','customers','Create and edit customers'),
('website.view','View websites','websites','View websites'),
('website.manage','Manage websites','websites','Create/edit/suspend websites'),
('website.publish','Publish websites','websites','Publish websites'),
('package.manage','Manage packages','packages','Manage packages and entitlements'),
('order.manage','Manage orders','orders','Review and approve orders'),
('payment.manage','Manage payments','payments','Manage payment state'),
('blog.manage','Manage blog','blog','Manage blog posts'),
('lead.manage','Manage leads','leads','Manage contact leads'),
('ticket.manage','Manage tickets','tickets','Manage support tickets'),
('user.manage','Manage users','users','Manage admin users'),
('role.manage','Manage roles','roles','Manage roles and permissions'),
('settings.manage','Manage settings','settings','Manage platform settings'),
('audit.view','View audit','audit','View audit log')
on conflict(code) do nothing;

create policy "customer own orders read" on public.orders for select
using(customer_email = (select email from public.profiles where auth_user_id=auth.uid() limit 1) or public.is_platform_admin());
