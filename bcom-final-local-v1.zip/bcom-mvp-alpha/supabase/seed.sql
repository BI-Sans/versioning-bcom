insert into public.website_categories (name,slug,description,sort_order) values
('Landing Page','landing-page','Single page marketing site',1),
('Company Profile','company-profile','Multi page corporate website',2),
('Portfolio','portfolio','Personal and professional portfolio',3),
('Restaurant / Cafe','restaurant-cafe','Restaurant and cafe website',4),
('Travel','travel','Travel packages and destinations',5),
('Product Catalog','product-catalog','Product catalog and inquiry website',6),
('Professional Services','professional-services','Professional service business',7),
('Wedding Invitation','wedding-invitation','Digital wedding invitation',8),
('Custom','custom','Custom web application',9)
on conflict (slug) do nothing;

insert into public.themes(category_id,name,slug,description,tokens_json)
select id,'Portfolio Modern','portfolio-modern','Clean modern portfolio', '{"colors":{"primary":"#091F3B","secondary":"#FCD708"},"typography":{"heading":"Manrope","body":"Inter"}}'::jsonb from public.website_categories where slug='portfolio'
on conflict(slug) do nothing;

insert into public.themes(category_id,name,slug,description,tokens_json)
select id,'Floral Romantic','floral-romantic','Soft wedding invitation theme', '{"colors":{"primary":"#7C4A5D","secondary":"#EFD6DE"}}'::jsonb from public.website_categories where slug='wedding-invitation'
on conflict(slug) do nothing;

insert into public.packages(category_id,name,slug,short_description,pricing_type,normal_price,promo_price,is_featured,show_on_homepage,status,sort_order,features_json)
select id,'Website Portfolio','website-portfolio','Website portfolio responsive untuk personal branding, freelancer, creator, dan profesional.','fixed',500000,200000,true,true,'active',1,'["Responsive","SEO Basic","Portfolio Gallery","Contact Form","B-COM Subdomain"]'::jsonb from public.website_categories where slug='portfolio'
on conflict(slug) do update set normal_price=excluded.normal_price,promo_price=excluded.promo_price,show_on_homepage=true;

insert into public.packages(category_id,name,slug,short_description,pricing_type,normal_price,is_featured,show_on_homepage,status,sort_order,features_json)
select id,'Company Profile','company-profile-basic','Website company profile profesional dan responsive.','starting_from',1500000,false,true,'active',2,'["Multi Page","Responsive","Contact Form","SEO Basic"]'::jsonb from public.website_categories where slug='company-profile'
on conflict(slug) do nothing;

insert into public.packages(category_id,name,slug,short_description,pricing_type,normal_price,is_featured,show_on_homepage,status,sort_order,features_json)
select id,'Wedding Invitation','wedding-invitation-basic','Undangan digital dengan RSVP, guestbook, guest management, dan personalized link.','fixed',150000,false,true,'active',3,'["Responsive Invitation","Countdown","RSVP","Guestbook","Personalized Guest Link","Message Generator"]'::jsonb from public.website_categories where slug='wedding-invitation'
on conflict(slug) do nothing;

-- Final Local v1 package tiers
update public.packages set tier='Basic', purchase_mode='direct', cta_label='Pilih Paket', badge='Promo', entitlements_json='{"max_pages":5,"max_storage_mb":100,"max_users":1,"seo":true,"analytics":"basic","custom_domain":false}'::jsonb where slug='website-portfolio';
update public.packages set tier='Business', purchase_mode='direct', cta_label='Pilih Paket', badge='Popular', entitlements_json='{"max_pages":10,"max_storage_mb":500,"max_users":3,"seo":true,"analytics":"standard","custom_domain":true}'::jsonb where slug='company-profile-basic';
update public.packages set tier='Basic', purchase_mode='direct', cta_label='Pilih Paket', entitlements_json='{"max_pages":1,"max_storage_mb":250,"max_users":2,"wedding":true,"guest_limit":300}'::jsonb where slug='wedding-invitation-basic';

insert into public.packages(category_id,name,slug,short_description,pricing_type,normal_price,is_featured,show_on_homepage,status,sort_order,features_json,tier,purchase_mode,cta_label,badge,entitlements_json)
select id,'Landing Page Basic','landing-page-basic','Landing page cepat untuk promosi produk, jasa, atau campaign.','fixed',350000,false,true,'active',10,'["1 Landing Page","Responsive","Basic SEO","Contact CTA"]'::jsonb,'Basic','direct','Pilih Paket',null,'{"max_pages":1,"max_storage_mb":75,"max_users":1}'::jsonb from public.website_categories where slug='landing-page'
on conflict(slug) do nothing;
insert into public.packages(category_id,name,slug,short_description,pricing_type,normal_price,is_featured,show_on_homepage,status,sort_order,features_json,tier,purchase_mode,cta_label,badge,entitlements_json)
select id,'Landing Page Business','landing-page-business','Landing page bisnis dengan section lebih lengkap dan analytics.','fixed',750000,true,true,'active',11,'["Conversion Sections","Responsive","SEO","Analytics","Custom Domain"]'::jsonb,'Business','direct','Pilih Paket','Most Popular','{"max_pages":3,"max_storage_mb":250,"max_users":2,"analytics":"standard"}'::jsonb from public.website_categories where slug='landing-page'
on conflict(slug) do nothing;
insert into public.packages(category_id,name,slug,short_description,pricing_type,normal_price,is_featured,show_on_homepage,status,sort_order,features_json,tier,purchase_mode,cta_label,badge,entitlements_json)
select id,'Landing Page Advanced','landing-page-advanced','Kebutuhan advanced dengan konsultasi, integrasi, dan pengembangan khusus.','quotation',0,false,true,'active',12,'["Custom Scope","Integration","Priority Support","Consultation"]'::jsonb,'Advanced','whatsapp','Hubungi Kami','Custom','{"custom":true,"priority_support":true}'::jsonb from public.website_categories where slug='landing-page'
on conflict(slug) do nothing;

-- Ready-made themes
insert into public.themes(category_id,name,slug,description,tokens_json,family,is_premium,is_featured,presets_json)
select id,v.name,v.slug,v.description,v.tokens::jsonb,v.family,v.premium,v.featured,v.presets::jsonb
from public.website_categories c
cross join (values
 ('SaaS Modern','saas-modern','Clean conversion-focused SaaS layout','{"colors":{"primary":"#0B2450","secondary":"#FFC400"},"typography":{"heading":"Manrope","body":"Inter"}}','Modern SaaS',false,true,'["Navy Yellow","Blue White","Dark"]'),
 ('Startup Gradient','startup-gradient','Bright modern startup presentation','{"colors":{"primary":"#1D4ED8","secondary":"#FACC15"}}','Modern SaaS',false,false,'["Blue","Violet"]'),
 ('Product Launch','product-launch','Focused product launch theme','{"colors":{"primary":"#111827","secondary":"#F59E0B"}}','Launch',false,false,'["Dark Gold","Clean"]')
) as v(name,slug,description,tokens,family,premium,featured,presets)
where c.slug='landing-page'
on conflict(slug) do nothing;

insert into public.themes(category_id,name,slug,description,tokens_json,family,is_premium,is_featured,presets_json)
select id,v.name,v.slug,v.description,v.tokens::jsonb,v.family,v.premium,v.featured,v.presets::jsonb
from public.website_categories c
cross join (values
 ('Corporate Blue','corporate-blue','Professional corporate website','{"colors":{"primary":"#0B2450","secondary":"#FFC400"}}','Corporate Modern',false,true,'["Navy","Blue","Green"]'),
 ('Executive White','executive-white','Minimal premium corporate appearance','{"colors":{"primary":"#111827","secondary":"#EAB308"}}','Corporate Modern',true,false,'["White Gold","Navy"]'),
 ('Technology Enterprise','technology-enterprise','Modern technology enterprise style','{"colors":{"primary":"#0F172A","secondary":"#2563EB"}}','Enterprise',true,false,'["Blue","Dark"]')
) as v(name,slug,description,tokens,family,premium,featured,presets)
where c.slug='company-profile'
on conflict(slug) do nothing;

insert into public.themes(category_id,name,slug,description,tokens_json,family,is_premium,is_featured,presets_json)
select id,v.name,v.slug,v.description,v.tokens::jsonb,v.family,v.premium,v.featured,v.presets::jsonb
from public.website_categories c
cross join (values
 ('Creative Grid','creative-grid','Portfolio with visual project grid','{"colors":{"primary":"#111827","secondary":"#FACC15"}}','Portfolio Creative',false,true,'["Light","Dark"]'),
 ('Developer Dark','developer-dark','Dark developer portfolio','{"colors":{"primary":"#020617","secondary":"#38BDF8"}}','Portfolio Creative',false,false,'["Blue","Green"]'),
 ('Minimal Personal','minimal-personal','Simple personal branding portfolio','{"colors":{"primary":"#0F172A","secondary":"#F59E0B"}}','Portfolio Minimal',false,false,'["Warm","Navy"]')
) as v(name,slug,description,tokens,family,premium,featured,presets)
where c.slug='portfolio'
on conflict(slug) do nothing;

insert into public.themes(category_id,name,slug,description,tokens_json,family,is_premium,is_featured,presets_json)
select id,v.name,v.slug,v.description,v.tokens::jsonb,v.family,v.premium,v.featured,v.presets::jsonb
from public.website_categories c
cross join (values
 ('Elegant Classic','elegant-classic','Timeless wedding invitation','{"colors":{"primary":"#5B3A4A","secondary":"#D8B4A0"}}','Wedding Elegant',false,true,'["Rose","Ivory"]'),
 ('Luxury Gold','luxury-gold','Luxury dark and gold wedding','{"colors":{"primary":"#111827","secondary":"#D4AF37"}}','Wedding Elegant',true,false,'["Black Gold","Emerald Gold"]'),
 ('Islamic Elegant','islamic-elegant','Elegant Islamic wedding theme','{"colors":{"primary":"#14532D","secondary":"#EAB308"}}','Wedding Cultural',false,false,'["Emerald","Ivory"]'),
 ('Batik Elegant','batik-elegant','Indonesian batik inspired wedding theme','{"colors":{"primary":"#422006","secondary":"#D97706"}}','Wedding Cultural',true,false,'["Brown Gold","Navy Gold"]')
) as v(name,slug,description,tokens,family,premium,featured,presets)
where c.slug='wedding-invitation'
on conflict(slug) do nothing;
