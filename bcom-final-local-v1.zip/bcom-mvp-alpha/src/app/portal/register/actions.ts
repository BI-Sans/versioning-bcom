"use server";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export async function registerCustomer(formData: FormData){
  const fullName=String(formData.get("full_name")||"").trim();
  const email=String(formData.get("email")||"").trim().toLowerCase();
  const password=String(formData.get("password")||"");
  const confirm=String(formData.get("confirm_password")||"");
  if(fullName.length<2) redirect("/portal/register?error=Nama%20terlalu%20pendek");
  if(password.length<8) redirect("/portal/register?error=Password%20minimal%208%20karakter");
  if(password!==confirm) redirect("/portal/register?error=Konfirmasi%20password%20tidak%20sama");
  const supabase=await createClient();
  const {error}=await supabase.auth.signUp({email,password,options:{data:{full_name:fullName},emailRedirectTo:`${process.env.APP_URL||"http://localhost:3000"}/portal/login?verified=1`}});
  if(error) redirect(`/portal/register?error=${encodeURIComponent(error.message)}`);
  redirect("/portal/login?registered=1");
}
