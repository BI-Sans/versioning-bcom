"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireTenantUser } from "@/services/auth/guards";
export async function createTicket(fd:FormData){ const {profile,memberships}=await requireTenantUser(); const s=await createClient(); const num=`TIC-${new Date().getFullYear()}-${Math.random().toString().slice(2,8)}`; const {error}=await s.from("support_tickets").insert({ticket_number:num,created_by:profile.id,tenant_id:memberships[0]?.tenant_id||null,category:String(fd.get("category")||"other"),priority:String(fd.get("priority")||"normal"),subject:String(fd.get("subject")||""),description:String(fd.get("description")||"")}); if(error) redirect(`/portal/tickets/new?error=${encodeURIComponent(error.message)}`); revalidatePath("/portal/tickets"); redirect("/portal/tickets?created=1"); }
