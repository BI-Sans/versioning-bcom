import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";

function slugify(input:string){return input.toLowerCase().normalize("NFKD").replace(/[^a-z0-9\s-]/g,"").trim().replace(/\s+/g,"-").replace(/-+/g,"-").slice(0,48)||"customer";}

async function attachRegisteredOwner(supabase:any,input:{tenantId:string;email:string}){
  const {data:role}=await supabase.from("roles").select("id").eq("name","Owner").eq("scope","tenant").maybeSingle();
  let {data:profile}=await supabase.from("profiles").select("id,email").ilike("email",input.email).maybeSingle();
  // The profile is created by the auth.users trigger. A tiny retry avoids transaction timing edge cases.
  for(let i=0;!profile&&i<4;i++){await new Promise(r=>setTimeout(r,150)); const res=await supabase.from("profiles").select("id,email").ilike("email",input.email).maybeSingle(); profile=res.data;}
  if(!profile) return {profileId:null,attached:false,reason:"Customer account not registered yet"};
  const {error}=await supabase.from("tenant_users").upsert({tenant_id:input.tenantId,user_id:profile.id,role_id:role?.id||null,status:"active",joined_at:new Date().toISOString()},{onConflict:"tenant_id,user_id"});
  if(error) throw new Error(`Membership creation failed: ${error.message}`);
  await supabase.from("tenants").update({owner_user_id:profile.id}).eq("id",input.tenantId);
  return {profileId:profile.id,attached:true};
}

export async function provisionWebsiteFromOrder(orderId:string){
 const supabase=createAdminClient();
 const {data:order,error:orderError}=await supabase.from("orders").select("*,packages(id,name,category_id)").eq("id",orderId).single();
 if(orderError||!order) throw new Error(orderError?.message||"Order not found");
 if(order.tenant_id){const {data:existing}=await supabase.from("websites").select("id,name,slug,status").eq("tenant_id",order.tenant_id).limit(1).maybeSingle();if(existing){const owner=await attachRegisteredOwner(supabase,{tenantId:order.tenant_id,email:order.customer_email});return{tenantId:order.tenant_id,website:existing,alreadyProvisioned:true,ownerAttached:owner.attached,ownerReason:owner.reason||null};}}
 const base=slugify(order.customer_name);const suffix=Math.random().toString(36).slice(2,6);const tenantSlug=`${base}-${suffix}`;
 const {data:tenant,error:tenantError}=await supabase.from("tenants").insert({name:order.customer_name,slug:tenantSlug,status:"active"}).select("id,name,slug").single();
 if(tenantError||!tenant)throw new Error(tenantError?.message||"Tenant creation failed");
 try{
  const categoryId=order.packages?.category_id??null;
  const {data:category}=categoryId?await supabase.from("website_categories").select("slug").eq("id",categoryId).maybeSingle():{data:null};
  const {data:theme}=categoryId?await supabase.from("themes").select("id").eq("category_id",categoryId).eq("status","active").order("is_featured",{ascending:false}).order("created_at").limit(1).maybeSingle():{data:null as any};
  const {data:website,error:websiteError}=await supabase.from("websites").insert({tenant_id:tenant.id,name:`${order.customer_name} Website`,slug:tenant.slug,category_id:categoryId,theme_id:theme?.id??null,status:"active",default_language:order.requirement_json?.language?.includes("English")?"en":"id",published_at:new Date().toISOString()}).select("id,name,slug,status").single();
  if(websiteError||!website)throw new Error(websiteError?.message||"Website creation failed");
  await supabase.from("brand_kits").insert({tenant_id:tenant.id,website_id:website.id,primary_color:"#071D49",secondary_color:"#FFC400",heading_font:"Manrope",body_font:"Inter"});
  const {data:home,error:pageError}=await supabase.from("pages").insert({tenant_id:tenant.id,website_id:website.id,name:"Home",slug:"",status:"published",is_homepage:true,published_at:new Date().toISOString()}).select("id").single();
  if(pageError||!home)throw new Error(pageError?.message||"Homepage creation failed");
  const responsive={desktop:{align:"left",paddingY:80,hidden:false},tablet:{align:"left",paddingY:64},mobile:{align:"left",paddingY:56,hidden:false}};
  const raw=category?.slug==="wedding-invitation"?[{section_type:"hero",variant:"centered",sort_order:1,content_json:{title:order.customer_name,description:"Our Wedding Invitation"}},{section_type:"content",variant:"centered",sort_order:2,content_json:{title:"Save the Date",description:"Edit wedding details from Wedding Manager."}},{section_type:"gallery",variant:"grid",sort_order:3,content_json:{title:"Our Gallery",description:"Upload moments from Media Manager."}},{section_type:"contact",variant:"cta",sort_order:4,content_json:{title:"Thank You",description:"Your presence and prayers mean so much to us."}}]:[{section_type:"hero",variant:"split-right",sort_order:1,content_json:{title:order.customer_name,description:`Welcome to ${order.customer_name}.`}}, {section_type:"about",variant:"image-left",sort_order:2,content_json:{title:"About Us",description:order.requirement_json?.notes||"Edit this content from the B-COM website editor."}}, {section_type:"contact",variant:"simple",sort_order:3,content_json:{title:"Contact",description:`Email: ${order.customer_email} · WhatsApp: ${order.customer_phone||"-"}`}}];
  const sections=raw.map((x:any)=>({...x,tenant_id:tenant.id,website_id:website.id,page_id:home.id,is_visible:true,draft_variant:x.variant,draft_content_json:x.content_json,draft_responsive_json:responsive,draft_is_visible:true,responsive_json:responsive}));
  const {error:sectionsError}=await supabase.from("page_sections").insert(sections);if(sectionsError)throw new Error(sectionsError.message);
  if(category?.slug==="wedding-invitation"){await supabase.from("wedding_profiles").insert({tenant_id:tenant.id,website_id:website.id});await supabase.from("wedding_message_templates").insert({tenant_id:tenant.id,website_id:website.id,name:"Formal",template_type:"formal",is_default:true,message_template:"Kepada Yth.\n{{guest_name}}\n\nDengan penuh rasa syukur, kami mengundang Bapak/Ibu/Saudara/i untuk menghadiri pernikahan {{couple_name}}.\n\n{{invitation_url}}\n\nTerima kasih."});}
  const owner=await attachRegisteredOwner(supabase,{tenantId:tenant.id,email:order.customer_email});
  await supabase.from("orders").update({tenant_id:tenant.id,status:"in_progress",updated_at:new Date().toISOString()}).eq("id",order.id);
  await supabase.from("audit_logs").insert({action:"website.provision",module:"provisioning",entity_type:"website",entity_id:website.id,tenant_id:tenant.id,new_values_json:{order_id:order.id,tenant_slug:tenant.slug,website_slug:website.slug,owner_attached:owner.attached,owner_note:owner.reason||null}});
  if(!owner.attached){await supabase.from("audit_logs").insert({action:"membership.pending",module:"provisioning",entity_type:"tenant",entity_id:tenant.id,tenant_id:tenant.id,new_values_json:{customer_email:order.customer_email,reason:owner.reason}});}
  return {tenantId:tenant.id,website,alreadyProvisioned:false,ownerAttached:owner.attached,ownerReason:owner.reason||null};
 }catch(error){await supabase.from("tenants").delete().eq("id",tenant.id);throw error;}
}
