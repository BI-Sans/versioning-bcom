# B-COM Website Platform — Final Local v1

Local-first B-COM website-as-a-service platform built with Next.js, TypeScript, Tailwind CSS, Supabase, and Gmail SMTP.

## Included in this local package

### Public B-COM website
- Modern navy/white/yellow SaaS UI
- Responsive navigation without public Admin button
- Website categories
- Slideable/autoplay package cards
- Package tier + purchase mode (`direct`, `quotation`, `contact`, `whatsapp`)
- Ready-made theme gallery
- Blog public pages
- Contact form / lead capture
- Footer matching the approved B-COM visual direction

### Customer Portal
- Email/password self-registration
- Email verification support through Supabase Auth
- Login
- Customer dashboard that also works before a customer has a tenant/website
- Browse packages from portal
- Multiple website-ready architecture
- Orders view
- Billing shell for manual/payment-provider phase
- Support Ticket creation/list
- Notifications
- Existing Website Management, Pages/Builder, Media, Brand Kit and Wedding module from Phase 1C

### Admin Portal
- Redesigned SaaS Admin shell
- Dashboard
- Customers
- Websites
- Orders
- Leads
- Support Tickets
- Packages + package tier/purchase mode
- Categories
- Ready-made Themes
- Landing CMS
- Blog CMS foundation
- Users & RBAC overview
- Analytics foundation
- System Settings

### Provisioning fix
The customer account is now self-registered. When an order is provisioned, B-COM looks up the registered customer by the order email and attaches that profile as Tenant Owner. Re-running provisioning for an already-created order also retries attaching the membership.

### Database additions
Migration `007_final_local_v1.sql` adds:
- package tiers / purchase modes / entitlements
- ready-made theme metadata
- blog categories/posts
- contact leads
- support tickets/messages
- notifications
- additional RBAC permissions
- customer access to own orders

## Requirements
- Node.js 20+ (Node 22 is fine)
- npm
- Supabase project
- Gmail App Password only if you want SMTP test/email

## 1. Environment file
Copy:

```powershell
Copy-Item .env.example .env.local
```

Fill `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY
SUPABASE_SERVICE_ROLE_KEY=YOUR_SECRET_OR_SERVICE_ROLE_KEY

EMAIL_USER=bekasi.computer22@gmail.com
EMAIL_APP_PASSWORD=YOUR_GMAIL_APP_PASSWORD
EMAIL_FROM_NAME=B-COM
ADMIN_NOTIFICATION_EMAIL=bekasi.computer22@gmail.com

APP_URL=http://localhost:3000
ROOT_DOMAIN=
PAYMENT_PROVIDER=manual
MIDTRANS_SERVER_KEY=
MIDTRANS_CLIENT_KEY=
MIDTRANS_IS_PRODUCTION=false
CRON_SECRET=
```

Never expose `SUPABASE_SERVICE_ROLE_KEY` or Gmail App Password in screenshots/chat.

## 2A. Fresh Supabase project
Run SQL files in this exact order:

```text
supabase/migrations/001_core.sql
supabase/migrations/002_website_engine.sql
supabase/migrations/003_commerce.sql
supabase/migrations/004_rls.sql
supabase/migrations/005_phase1b.sql
supabase/migrations/006_phase1c.sql
supabase/migrations/007_final_local_v1.sql
supabase/seed.sql
```

For the early table-creation migrations, Supabase may warn that RLS is not enabled yet. Use **Run without RLS** because `004_rls.sql` and later migrations apply the required RLS policies.

## 2B. Existing Phase 1C Supabase project
If migrations `001` through `006` and the old seed were already executed, run only:

```text
supabase/migrations/007_final_local_v1.sql
supabase/seed.sql
```

The seed uses upserts/`on conflict` where applicable and adds the newer packages/themes.

## 3. Supabase Authentication settings
Authentication → URL Configuration:

```text
Site URL:
http://localhost:3000

Redirect URLs:
http://localhost:3000/**
```

Customer registration uses Supabase Auth. If email confirmation is enabled, the customer confirms the email before logging in.

## 4. Super Admin
Create the admin Auth user in Supabase Authentication → Users, then use `supabase/README_SETUP.sql` to mark that profile as `is_platform_admin = true`.

Admin login:

```text
http://localhost:3000/admin/login
```

Admin login is intentionally not shown on the public website.

## 5. Install and run

```powershell
npm install
npm run dev
```

Open:

```text
Public Website  http://localhost:3000
Customer Login  http://localhost:3000/portal/login
Customer Signup http://localhost:3000/portal/register
Admin Login     http://localhost:3000/admin/login
Blog            http://localhost:3000/blog
Contact         http://localhost:3000/contact
```

## 6. Recommended test flow

```text
1. Admin Login
2. Check packages/themes
3. Customer self-registers using an email address
4. Customer verifies email (if enabled) and logs in
5. Customer without website sees onboarding/Browse Packages instead of "No membership"
6. Customer submits an order with the SAME registered email
7. Admin opens the order and runs Approve & Create Website
8. Provisioning creates Tenant + Website and attaches customer as Owner
9. Customer refreshes/logs in → My Websites
10. Test Page Builder
11. Test Media Library
12. For Wedding package/category → test Wedding Manager
13. Test Customer Support Ticket → Admin Support Tickets
14. Test Advanced package → Contact form / lead
```

## 7. Existing order with `No membership`
If a website was created before this version, make sure the customer first registers with the same email used in the order. Then open the existing order in Admin and run the provisioning/approve action again. The new provisioning code detects the existing website and retries attaching the customer Owner membership instead of creating a duplicate website.

## 8. Payment in local version
Keep:

```env
PAYMENT_PROVIDER=manual
```

This package keeps the payment architecture ready for Midtrans/Xendit, but real gateway transactions should be configured and tested separately using sandbox credentials before production.

## 9. Ready-made themes included
Examples seeded in this version:
- SaaS Modern
- Startup Gradient
- Product Launch
- Corporate Blue
- Executive White
- Technology Enterprise
- Creative Grid
- Developer Dark
- Minimal Personal
- Elegant Classic
- Luxury Gold
- Islamic Elegant
- Batik Elegant
- Existing Portfolio Modern / Floral Romantic

Customers choose a ready-made theme and then customize logo, colors, content, images, sections, and responsive settings using the website tools.

## 10. Important production note
This ZIP is intended for **local development/testing**. Before commercial production, complete payment gateway integration, production-grade backup/monitoring, 2FA/rate limits, full translation coverage, and production hosting plan review.

## Build verification note
The source was statically checked for TypeScript/TSX parse errors during generation. The generation environment could not complete `npm install` because package installation timed out, so a full `npm run build` was not executed here. Run `npm install`, `npm run lint`, and `npm run build` locally and report any error output for targeted fixes.
