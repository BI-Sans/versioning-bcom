import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { PublicNavbar } from "@/components/public-navbar";
import { PublicFooter } from "@/components/public-footer";
import { createClient } from "@/lib/supabase/server";

async function getPost(slug: string) {
  const s = await createClient();
  const { data } = await s
    .from("blog_posts")
    .select("title,excerpt,content,published_at,seo_title,meta_description,featured_image_url,og_image_url,canonical_url")
    .eq("slug", slug)
    .eq("status", "published")
    .maybeSingle();
  return data;
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const post = await getPost(slug);
  if (!post) return {};
  return {
    title: post.seo_title || post.title,
    description: post.meta_description || post.excerpt || undefined,
    alternates: post.canonical_url ? { canonical: post.canonical_url } : undefined,
    openGraph: {
      title: post.seo_title || post.title,
      description: post.meta_description || post.excerpt || undefined,
      type: "article",
      publishedTime: post.published_at || undefined,
      images: post.og_image_url || post.featured_image_url ? [post.og_image_url || post.featured_image_url] : undefined,
    },
  };
}

export default async function BlogPost({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const data = await getPost(slug);
  if (!data) notFound();

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: data.title,
    description: data.meta_description || data.excerpt,
    datePublished: data.published_at,
    image: data.og_image_url || data.featured_image_url || undefined,
    publisher: { "@type": "Organization", name: "B-COM" },
  };

  return (
    <main className="bg-white">
      <PublicNavbar />
      <article className="container-bcom max-w-4xl py-20">
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
        <div className="section-kicker">B-COM Insight</div>
        <h1 className="mt-3 text-4xl font-black leading-tight text-bcom-navy md:text-5xl">{data.title}</h1>
        <p className="mt-5 text-lg leading-8 text-slate-500">{data.excerpt}</p>
        {data.featured_image_url ? <img src={data.featured_image_url} alt={data.title} className="mt-9 max-h-[460px] w-full rounded-3xl object-cover" /> : null}
        <div className="mt-10 whitespace-pre-wrap rounded-2xl bg-white text-base leading-8 text-slate-700">{data.content}</div>
      </article>
      <PublicFooter />
    </main>
  );
}
