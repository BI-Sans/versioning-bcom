import type { Metadata } from "next";
import Link from "next/link";
import { PublicNavbar } from "@/components/public-navbar";
import { PublicFooter } from "@/components/public-footer";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Blog Website, SEO & Bisnis | B-COM",
  description: "Insight praktis tentang website bisnis, landing page, SEO, template website, performa, dan digital presence dari B-COM.",
};

export default async function Blog() {
  const s = await createClient();
  const { data } = await s
    .from("blog_posts")
    .select("id,title,slug,excerpt,published_at,featured_image_url,blog_categories(name)")
    .eq("status", "published")
    .order("published_at", { ascending: false });

  return (
    <main className="bg-white">
      <PublicNavbar />
      <section className="py-20">
        <div className="container-bcom">
          <div className="section-kicker">B-COM Blog</div>
          <h1 className="section-title">Insights untuk Website, SEO & Bisnis.</h1>
          <p className="mt-4 max-w-2xl text-slate-500">Artikel praktis untuk membantu bisnis memilih, membangun, dan mengembangkan website yang lebih efektif.</p>
          <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {(data || []).length ? (
              (data || []).map((p: any) => (
                <Link href={`/blog/${p.slug}`} key={p.id} className="card hover-lift overflow-hidden">
                  {p.featured_image_url ? <img src={p.featured_image_url} alt={p.title} className="h-44 w-full object-cover" /> : null}
                  <div className="p-6">
                    <div className="text-xs font-bold text-blue-600">{p.blog_categories?.name || "Insight"}</div>
                    <h2 className="mt-3 text-xl font-black text-bcom-navy">{p.title}</h2>
                    <p className="mt-3 text-sm leading-6 text-slate-500">{p.excerpt}</p>
                    <div className="mt-5 text-sm font-bold text-blue-600">Baca artikel →</div>
                  </div>
                </Link>
              ))
            ) : (
              <div className="card col-span-full p-8 text-center text-slate-500">Belum ada artikel published. Kelola melalui Admin → Blog CMS.</div>
            )}
          </div>
        </div>
      </section>
      <PublicFooter />
    </main>
  );
}
