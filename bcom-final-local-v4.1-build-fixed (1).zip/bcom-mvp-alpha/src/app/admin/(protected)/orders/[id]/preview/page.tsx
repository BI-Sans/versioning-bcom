import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { ArrowLeft, ExternalLink } from "lucide-react";
import { DemoOrderSite } from "@/components/demo-order-site";

export const dynamic = "force-dynamic";

export default async function DemoOrderPreviewPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: order } = await supabase
    .from("orders")
    .select("id,order_number,customer_name,customer_email,customer_phone,is_demo,requirement_json,packages(name,slug,website_categories(name,slug))")
    .eq("id", id)
    .single();

  if (!order || !order.is_demo) notFound();
  const category = (order as any).packages?.website_categories;
  const requirement = (order as any).requirement_json || {};

  return (
    <div>
      <div className="mb-6 flex flex-col justify-between gap-4 xl:flex-row xl:items-center">
        <div>
          <Link href={`/admin/orders/${order.id}`} className="inline-flex items-center gap-2 text-sm font-bold text-blue-600 hover:underline">
            <ArrowLeft size={16}/> Kembali ke Order
          </Link>
          <h1 className="mt-3 text-3xl font-black text-bcom-navy">Demo Website Preview</h1>
          <p className="mt-2 text-slate-500">{order.order_number} · {category?.name || "Website"} · preview read-only berdasarkan requirement demo.</p>
        </div>
        <div className="inline-flex items-center gap-2 rounded-xl bg-amber-50 px-4 py-3 text-sm font-bold text-amber-700">
          <ExternalLink size={16}/> Admin Preview Mode
        </div>
      </div>

      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl">
        <div className="flex items-center gap-3 border-b border-slate-200 bg-slate-50 px-4 py-3">
          <div className="flex gap-1.5"><span className="h-3 w-3 rounded-full bg-red-400"/><span className="h-3 w-3 rounded-full bg-amber-400"/><span className="h-3 w-3 rounded-full bg-emerald-400"/></div>
          <div className="mx-auto max-w-xl flex-1 truncate rounded-lg border border-slate-200 bg-white px-4 py-2 text-center text-xs text-slate-400">preview.b-com.local/{category?.slug || "demo"}/{order.order_number.toLowerCase()}</div>
        </div>
        <DemoOrderSite categorySlug={category?.slug || "custom"} categoryName={category?.name || "Website"} requirement={requirement} />
      </div>
    </div>
  );
}
