import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { formatIDR } from "@/lib/utils";

export const dynamic = "force-dynamic";
export default async function OrdersPage() {
  const supabase = await createClient();
  const { data } = await supabase
    .from("orders")
    .select("id,order_number,customer_name,customer_email,status,total_amount,created_at,is_demo,packages(name,website_categories(name))")
    .order("created_at", { ascending: false });

  return <div>
    <div>
      <h1 className="text-3xl font-black text-bcom-navy">Orders</h1>
      <p className="mt-2 text-slate-500">Order customer dan contoh demo untuk setiap kategori website.</p>
    </div>
    <div className="card mt-7 overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead className="bg-slate-50 text-slate-500"><tr>{["Order","Customer","Category / Package","Amount","Status","Created","Action"].map(x=><th key={x} className="px-4 py-3">{x}</th>)}</tr></thead>
        <tbody>{(data??[]).map((o:any)=><tr key={o.id} className="border-t border-slate-100">
          <td className="px-4 py-3 font-semibold"><Link className="text-bcom-blue hover:underline" href={`/admin/orders/${o.id}`}>{o.order_number}</Link>{o.is_demo?<span className="ml-2 rounded-full bg-amber-50 px-2 py-1 text-[10px] font-black text-amber-700">DEMO</span>:null}</td>
          <td className="px-4 py-3">{o.customer_name}<div className="text-xs text-slate-400">{o.customer_email}</div></td>
          <td className="px-4 py-3"><div className="font-semibold text-slate-700">{o.packages?.website_categories?.name||"-"}</div><div className="text-xs text-slate-400">{o.packages?.name}</div></td>
          <td className="px-4 py-3">{formatIDR(o.total_amount)}</td>
          <td className="px-4 py-3"><span className="rounded-full bg-slate-100 px-2 py-1 text-xs font-semibold">{o.status}</span></td>
          <td className="px-4 py-3">{new Date(o.created_at).toLocaleDateString("id-ID")}</td>
          <td className="px-4 py-3">{o.is_demo?<Link href={`/admin/orders/${o.id}/preview`} className="btn-outline whitespace-nowrap">Preview Demo</Link>:<Link href={`/admin/orders/${o.id}`} className="text-sm font-bold text-blue-600 hover:underline">View</Link>}</td>
        </tr>)}</tbody>
      </table>
    </div>
  </div>;
}
