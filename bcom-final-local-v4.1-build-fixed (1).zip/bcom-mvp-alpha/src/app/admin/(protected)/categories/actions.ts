"use server";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { requirePlatformAdmin } from "@/services/auth/guards";
const schema=z.object({name:z.string().min(2),slug:z.string().regex(/^[a-z0-9-]+$/),description:z.string().optional(),status:z.enum(["active","inactive"]).default("active")});
export async function createCategory(fd:FormData){await requirePlatformAdmin();const p=schema.parse({...Object.fromEntries(fd.entries()),status:"active"});const s=await createClient();const {error}=await s.from("website_categories").insert(p);if(error)throw new Error(error.message);revalidatePath("/");revalidatePath("/admin/categories")}
export async function updateCategory(id:string,fd:FormData){await requirePlatformAdmin();const p=schema.parse(Object.fromEntries(fd.entries()));const s=await createClient();const {error}=await s.from("website_categories").update(p).eq("id",id);if(error)throw new Error(error.message);revalidatePath("/");revalidatePath("/admin/categories")}
export async function deactivateCategory(id:string){await requirePlatformAdmin();const s=await createClient();const {error}=await s.from("website_categories").update({status:"inactive"}).eq("id",id);if(error)throw new Error(error.message);revalidatePath("/");revalidatePath("/admin/categories")}
