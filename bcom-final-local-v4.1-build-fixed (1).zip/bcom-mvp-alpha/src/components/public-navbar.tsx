import Link from "next/link";
import { Logo } from "@/components/logo";
import { Menu, UserRound } from "lucide-react";

export function PublicNavbar() {
  return <>
    <div className="bg-bcom-navy px-4 py-2 text-center text-xs font-semibold text-white">🎁 Spesial Launching! Dapatkan paket website terbaik untuk bisnis Anda.</div>
    <header className="sticky top-0 z-40 border-b border-slate-200/70 bg-white/90 backdrop-blur-xl">
      <div className="container-bcom flex h-20 items-center justify-between gap-6">
        <Link href="/"><Logo /></Link>
        <nav className="hidden items-center gap-6 text-sm font-semibold text-slate-700 lg:flex">
          <Link href="/">Beranda</Link><Link href="/#services">Layanan</Link><Link href="/#packages">Paket Website</Link><Link href="/#templates">Template</Link><Link href="/#themes">Tema</Link><Link href="/#portfolio">Portfolio</Link><Link href="/blog">Blog</Link><Link href="/#about">Tentang Kami</Link><Link href="/contact">Kontak</Link>
        </nav>
        <div className="hidden items-center gap-2 md:flex"><Link href="/portal/login" className="btn-outline gap-2"><UserRound size={17}/>Masuk</Link><Link href="/portal/register" className="btn-primary">Daftar Sekarang</Link></div>
        <Link href="/portal/login" className="btn-outline md:hidden"><Menu size={18}/></Link>
      </div>
    </header>
  </>;
}
