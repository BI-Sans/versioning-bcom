-- B-COM Final Local v3
-- SEO blog demo content + one safe demo order per website category.
-- Demo orders are preview-only and should not create users/tenants.

alter table public.orders
  add column if not exists is_demo boolean not null default false;

-- Ensure every category has at least one package so demo orders can represent all categories.
insert into public.packages(category_id,name,slug,short_description,pricing_type,normal_price,is_featured,show_on_homepage,status,sort_order,features_json,tier,purchase_mode,cta_label,entitlements_json)
select id,'Restaurant / Cafe Starter','restaurant-cafe-starter','Website restoran atau cafe dengan menu, galeri, lokasi, dan tombol reservasi.','fixed',650000,false,true,'active',20,'["Menu Showcase","Gallery","Location & Maps","WhatsApp Reservation","Responsive"]'::jsonb,'Basic','direct','Pilih Paket','{"max_pages":5,"max_storage_mb":250,"max_users":2}'::jsonb from public.website_categories where slug='restaurant-cafe'
on conflict(slug) do update set category_id=excluded.category_id;

insert into public.packages(category_id,name,slug,short_description,pricing_type,normal_price,is_featured,show_on_homepage,status,sort_order,features_json,tier,purchase_mode,cta_label,entitlements_json)
select id,'Travel Business','travel-business','Website travel untuk menampilkan paket perjalanan, destinasi, itinerary, dan inquiry.','fixed',950000,false,true,'active',21,'["Travel Packages","Destination Gallery","Itinerary","Inquiry Form","WhatsApp CTA"]'::jsonb,'Business','direct','Pilih Paket','{"max_pages":8,"max_storage_mb":500,"max_users":3}'::jsonb from public.website_categories where slug='travel'
on conflict(slug) do update set category_id=excluded.category_id;

insert into public.packages(category_id,name,slug,short_description,pricing_type,normal_price,is_featured,show_on_homepage,status,sort_order,features_json,tier,purchase_mode,cta_label,entitlements_json)
select id,'Product Catalog Business','product-catalog-business','Katalog produk online tanpa checkout kompleks, cocok untuk inquiry dan B2B.','fixed',850000,false,true,'active',22,'["Product Catalog","Category Filter","Product Detail","Inquiry CTA","Responsive"]'::jsonb,'Business','direct','Pilih Paket','{"max_pages":10,"max_storage_mb":750,"max_users":3}'::jsonb from public.website_categories where slug='product-catalog'
on conflict(slug) do update set category_id=excluded.category_id;

insert into public.packages(category_id,name,slug,short_description,pricing_type,normal_price,is_featured,show_on_homepage,status,sort_order,features_json,tier,purchase_mode,cta_label,entitlements_json)
select id,'Professional Services','professional-services-business','Website profesional untuk konsultan, firma, agency, klinik, dan penyedia jasa.','fixed',900000,false,true,'active',23,'["Service Pages","Team Profile","Testimonials","Lead Form","SEO Basic"]'::jsonb,'Business','direct','Pilih Paket','{"max_pages":8,"max_storage_mb":400,"max_users":3}'::jsonb from public.website_categories where slug='professional-services'
on conflict(slug) do update set category_id=excluded.category_id;

insert into public.packages(category_id,name,slug,short_description,pricing_type,normal_price,is_featured,show_on_homepage,status,sort_order,features_json,tier,purchase_mode,cta_label,badge,entitlements_json)
select id,'Custom Website Solution','custom-website-solution','Kebutuhan website atau web application khusus berdasarkan konsultasi dan scope.','quotation',0,false,true,'active',24,'["Custom Requirement","Consultation","Integration","Custom Workflow","Priority Support"]'::jsonb,'Advanced','contact','Konsultasi','Custom','{"custom":true,"priority_support":true}'::jsonb from public.website_categories where slug='custom'
on conflict(slug) do update set category_id=excluded.category_id;

-- Additional ready-made template for the Custom category.
insert into public.website_templates(category_id,name,slug,description,preview_image_url,tags,is_featured,is_premium,sort_order)
select id,'Custom Business Solution','custom-business-solution','Flexible modern starting point for custom business applications and service websites.','https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=1400&auto=format&fit=crop',array['custom','business','solution'],false,true,110
from public.website_categories where slug='custom'
on conflict(slug) do update set preview_image_url=excluded.preview_image_url,description=excluded.description;

-- SEO-oriented published articles for local/demo testing.
with c as (select id,slug from public.blog_categories)
insert into public.blog_posts(category_id,title,slug,excerpt,content,featured_image_url,status,published_at,seo_title,meta_description,og_image_url,language)
values
((select id from c where slug='website'),
 'Mengapa Bisnis Perlu Website Profesional di 2026?',
 'mengapa-bisnis-perlu-website-profesional-2026',
 'Website profesional membantu bisnis membangun kredibilitas, ditemukan di Google, dan mengubah calon pelanggan menjadi inquiry.',
 'Website profesional bukan sekadar kartu nama digital. Bagi bisnis, website adalah aset yang bekerja selama 24 jam untuk menjelaskan layanan, membangun kepercayaan, dan membantu calon pelanggan mengambil keputusan.\n\n1. Meningkatkan kredibilitas bisnis\nCalon pelanggan biasanya melakukan pencarian sebelum menghubungi sebuah bisnis. Website dengan profil perusahaan, layanan, portfolio, testimoni, alamat, dan informasi kontak yang jelas membuat bisnis terlihat lebih serius dan mudah dipercaya.\n\n2. Membantu bisnis ditemukan melalui Google\nWebsite memberi ruang untuk membuat halaman yang relevan dengan layanan dan kata kunci yang dicari pelanggan. Struktur halaman yang baik, judul yang jelas, kecepatan website, mobile friendly, dan konten yang bermanfaat menjadi fondasi SEO.\n\n3. Menjadi pusat informasi yang dapat dikontrol\nBerbeda dengan media sosial, website adalah kanal yang dapat Anda atur sendiri. Informasi harga, layanan, FAQ, portfolio, hingga formulir kontak dapat disusun berdasarkan kebutuhan bisnis.\n\n4. Mendukung proses penjualan\nLanding page, tombol WhatsApp, formulir inquiry, katalog, serta call-to-action dapat membantu mengarahkan pengunjung dari sekadar membaca menjadi menghubungi bisnis.\n\n5. Bisa berkembang bersama bisnis\nWebsite dapat dimulai dari sederhana lalu dikembangkan dengan blog, analytics, customer portal, katalog, booking, atau integrasi lain sesuai pertumbuhan usaha.\n\nB-COM menyediakan beberapa kategori website dan template siap pakai agar proses pembuatan lebih cepat. Customer dapat memilih paket, theme, dan template, kemudian menyesuaikan logo, warna, gambar, serta konten sesuai brand.',
 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1400&auto=format&fit=crop','published',now()-interval '1 day',
 'Website Profesional untuk Bisnis: Manfaat dan Tips 2026 | B-COM',
 'Pelajari alasan bisnis membutuhkan website profesional, manfaat SEO, kredibilitas, dan cara website membantu meningkatkan inquiry pelanggan.',
 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1400&auto=format&fit=crop','id'),

((select id from c where slug='seo'),
 'SEO Dasar untuk Website Bisnis: Panduan Praktis bagi Pemula',
 'seo-dasar-website-bisnis-panduan-pemula',
 'Panduan SEO dasar untuk membantu website bisnis lebih mudah dipahami mesin pencari dan lebih relevan bagi calon pelanggan.',
 'SEO atau Search Engine Optimization adalah proses meningkatkan kualitas website agar mudah dipahami mesin pencari dan memberikan pengalaman yang baik kepada pengguna. SEO tidak harus dimulai dengan teknik yang rumit.\n\nMulai dari keyword yang relevan\nGunakan kata dan frasa yang benar-benar dicari calon pelanggan. Hindari memasukkan kata kunci secara berlebihan. Judul halaman, heading, deskripsi layanan, dan artikel harus tetap alami dan bermanfaat.\n\nBuat struktur halaman yang jelas\nSetiap halaman sebaiknya memiliki satu fokus utama. Gunakan heading yang berurutan, URL yang singkat, navigation yang mudah dipahami, dan internal link menuju halaman terkait.\n\nOptimalkan title dan meta description\nSEO title membantu mesin pencari memahami topik halaman. Meta description memberikan ringkasan yang dapat meningkatkan kemungkinan pengguna mengklik hasil pencarian.\n\nPerhatikan mobile dan kecepatan\nBanyak pengunjung mengakses website melalui smartphone. Layout responsive, gambar yang terkompresi, dan ukuran file yang efisien membantu pengalaman pengguna dan performa website.\n\nTambahkan konten berkualitas\nBlog dapat menjawab pertanyaan calon pelanggan dan menambah cakupan topik website. Artikel yang relevan lebih berguna daripada banyak artikel tipis yang tidak memiliki tujuan.\n\nPantau dan perbaiki\nSEO adalah proses berkelanjutan. Periksa halaman yang banyak dikunjungi, kata kunci yang relevan, broken link, metadata yang kosong, dan halaman yang perlu diperbarui.\n\nB-COM dirancang dengan pengaturan SEO per halaman, blog SEO, sitemap, robots, metadata, serta pengembangan SEO health dashboard pada roadmap platform.',
 'https://images.unsplash.com/photo-1432888622747-4eb9a8efeb07?q=80&w=1400&auto=format&fit=crop','published',now()-interval '2 days',
 'SEO Dasar Website Bisnis untuk Pemula | B-COM',
 'Panduan SEO dasar: keyword, title, meta description, struktur halaman, mobile friendly, kecepatan, dan konten blog untuk website bisnis.',
 'https://images.unsplash.com/photo-1432888622747-4eb9a8efeb07?q=80&w=1400&auto=format&fit=crop','id'),

((select id from c where slug='business'),
 'Landing Page vs Company Profile: Mana yang Cocok untuk Bisnis Anda?',
 'landing-page-vs-company-profile',
 'Kenali perbedaan landing page dan company profile agar Anda memilih jenis website sesuai target bisnis dan kebutuhan customer.',
 'Landing page dan company profile sama-sama berguna, tetapi memiliki tujuan yang berbeda. Memilih jenis website berdasarkan tujuan akan membantu biaya dan struktur konten lebih efektif.\n\nLanding page cocok untuk satu tujuan utama\nLanding page biasanya fokus pada satu produk, satu layanan, campaign, event, atau promosi tertentu. Semua section diarahkan menuju call-to-action seperti WhatsApp, formulir, registrasi, atau pembelian.\n\nCompany profile cocok untuk informasi bisnis yang lebih lengkap\nCompany profile biasanya terdiri dari beberapa halaman, misalnya Home, About, Services, Portfolio, Clients, dan Contact. Model ini cocok untuk perusahaan yang ingin menampilkan kredibilitas dan banyak layanan.\n\nKapan memilih landing page?\nPilih landing page jika Anda sedang menjalankan iklan, meluncurkan produk, menguji penawaran baru, atau membutuhkan website yang cepat dan fokus conversion.\n\nKapan memilih company profile?\nPilih company profile apabila calon pelanggan perlu mengenal perusahaan secara lebih lengkap sebelum menghubungi Anda, terutama untuk bisnis B2B dan jasa profesional.\n\nBisa menggunakan keduanya\nBanyak bisnis menggunakan company profile sebagai website utama dan landing page terpisah untuk campaign tertentu. Dengan platform multi-website, satu customer dapat mengelola lebih dari satu website sesuai kebutuhannya.',
 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1400&auto=format&fit=crop','published',now()-interval '3 days',
 'Landing Page vs Company Profile: Perbedaan dan Pilihan | B-COM',
 'Bandingkan landing page dan company profile, fungsi, manfaat, dan kapan bisnis sebaiknya menggunakan masing-masing jenis website.',
 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1400&auto=format&fit=crop','id'),

((select id from c where slug='website'),
 '7 Elemen Penting agar Landing Page Lebih Efektif Menghasilkan Leads',
 'elemen-landing-page-efektif-menghasilkan-leads',
 'Hero yang jelas, social proof, manfaat, CTA, FAQ, dan kecepatan halaman adalah beberapa elemen penting landing page conversion.',
 'Landing page yang menarik belum tentu menghasilkan leads. Tujuan utamanya adalah membantu pengunjung memahami penawaran dan mengambil tindakan dengan hambatan seminimal mungkin.\n\n1. Headline yang langsung menjelaskan manfaat\nPengunjung harus memahami apa yang ditawarkan dalam beberapa detik. Gunakan headline yang sederhana dan spesifik.\n\n2. Call-to-action yang terlihat jelas\nTentukan satu tindakan utama seperti Hubungi Kami, Minta Penawaran, atau Pesan Sekarang. CTA dapat diulang pada beberapa bagian halaman tanpa membuat tampilan berlebihan.\n\n3. Visual yang relevan\nGunakan gambar produk, layanan, hasil pekerjaan, atau mockup yang benar-benar membantu memahami penawaran. Optimalkan gambar agar tidak memperlambat halaman.\n\n4. Manfaat, bukan hanya daftar fitur\nJelaskan bagaimana produk atau layanan membantu customer, bukan hanya menyebut spesifikasi.\n\n5. Bukti kepercayaan\nPortfolio, testimoni, client logo, studi kasus, dan informasi bisnis meningkatkan rasa percaya.\n\n6. FAQ\nFAQ dapat menjawab keberatan umum seperti harga, proses, durasi, revisi, atau support.\n\n7. Mobile friendly dan cepat\nPastikan CTA mudah ditekan, teks mudah dibaca, dan section tidak terlalu berat pada smartphone.\n\nB-COM menyediakan ready-made template sehingga struktur dasar conversion dapat dipilih terlebih dahulu lalu disesuaikan dengan brand customer.',
 'https://images.unsplash.com/photo-1559028012-481c04fa702d?q=80&w=1400&auto=format&fit=crop','published',now()-interval '4 days',
 '7 Elemen Landing Page Efektif untuk Menghasilkan Leads | B-COM',
 'Pelajari tujuh elemen landing page efektif: headline, CTA, visual, manfaat, social proof, FAQ, mobile friendly, dan performa.',
 'https://images.unsplash.com/photo-1559028012-481c04fa702d?q=80&w=1400&auto=format&fit=crop','id'),

((select id from c where slug='technology'),
 'Mengapa Website Responsive dan Cepat Penting untuk Pengalaman Customer?',
 'website-responsive-cepat-penting-untuk-customer',
 'Website responsive dan cepat membantu pengunjung menemukan informasi dengan nyaman di desktop, tablet, maupun smartphone.',
 'Pengalaman pengguna menjadi salah satu faktor utama apakah pengunjung akan melanjutkan membaca atau meninggalkan sebuah website. Dua fondasi pentingnya adalah responsive design dan performa.\n\nResponsive berarti layout menyesuaikan perangkat\nWebsite harus tetap mudah digunakan pada desktop, tablet, dan smartphone. Bukan hanya mengecilkan tampilan desktop, tetapi mengatur kembali ukuran font, grid, navigation, spacing, serta posisi CTA.\n\nKecepatan memengaruhi kenyamanan\nGambar yang terlalu besar, script berlebihan, dan komponen yang tidak dioptimalkan dapat membuat halaman lambat. Karena itu media perlu dikompresi dan asset dimuat secara efisien.\n\nMobile adalah prioritas\nBanyak calon customer pertama kali membuka link dari WhatsApp atau media sosial menggunakan smartphone. Jika tombol terlalu kecil atau halaman sulit dibaca, peluang conversion bisa berkurang.\n\nGunakan animasi dengan bijak\nAnimasi dapat membuat pengalaman terasa modern, tetapi harus ringan dan tidak mengganggu. Sistem sebaiknya juga menghormati pengaturan reduced motion.\n\nB-COM menggunakan responsive engine, image optimization roadmap, serta design system yang konsisten agar template dapat tetap nyaman digunakan pada berbagai ukuran layar.',
 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1400&auto=format&fit=crop','published',now()-interval '5 days',
 'Website Responsive dan Cepat: Mengapa Penting? | B-COM',
 'Ketahui pentingnya responsive design, performa, mobile friendly, optimasi gambar, dan animasi ringan untuk pengalaman customer.',
 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1400&auto=format&fit=crop','id'),

((select id from c where slug='business'),
 'Cara Memilih Template Website yang Sesuai dengan Jenis Usaha',
 'cara-memilih-template-website-sesuai-usaha',
 'Template siap pakai mempercepat pembuatan website, tetapi pilihan layout tetap harus mengikuti karakter bisnis dan tujuan website.',
 'Template website yang baik bukan hanya yang terlihat menarik. Pilihan template harus mendukung tujuan bisnis dan memudahkan customer menemukan informasi penting.\n\nMulai dari kategori usaha\nWebsite cafe membutuhkan penekanan pada menu, galeri, lokasi, dan reservasi. Website jasa profesional membutuhkan service, team, testimonial, dan lead form. Travel membutuhkan paket, destinasi, dan itinerary.\n\nPerhatikan tujuan utama\nTentukan apakah website bertujuan menghasilkan leads, memperkenalkan perusahaan, menampilkan portfolio, membagikan katalog, atau mendukung event.\n\nPilih struktur yang sudah mendekati kebutuhan\nSemakin dekat struktur template dengan kebutuhan, semakin sedikit perubahan yang diperlukan. Customer cukup mengganti logo, warna, teks, gambar, kontak, dan beberapa section.\n\nPeriksa versi mobile\nPreview template sebaiknya tidak hanya desktop. Pastikan navigation, card, galeri, dan CTA tetap nyaman di mobile.\n\nJangan takut menyesuaikan brand\nTemplate adalah titik awal. Gunakan brand kit untuk menerapkan warna, typography, logo, dan gaya visual bisnis tanpa mengubah fondasi layout.\n\nDi B-COM, Theme mengatur design system sedangkan Website Template merupakan contoh website siap pakai. Dengan pemisahan ini, customer bisa memilih struktur yang sudah jadi lalu menyesuaikan tampilan sesuai identitas brand.',
 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?q=80&w=1400&auto=format&fit=crop','published',now()-interval '6 days',
 'Cara Memilih Template Website Sesuai Jenis Usaha | B-COM',
 'Tips memilih template website berdasarkan kategori bisnis, tujuan website, struktur halaman, mobile preview, dan identitas brand.',
 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?q=80&w=1400&auto=format&fit=crop','id'),

((select id from c where slug='seo'),
 'Blog untuk SEO: Cara Membuat Konten yang Membantu Bisnis Ditemukan',
 'blog-untuk-seo-bisnis',
 'Blog dapat memperluas topik yang ditemukan Google sekaligus menjawab pertanyaan calon customer sebelum mereka menghubungi bisnis.',
 'Blog yang dikelola dengan baik membantu website membahas lebih banyak pertanyaan yang relevan dengan customer. Namun tujuan utamanya bukan sekadar menerbitkan artikel sebanyak mungkin.\n\nPilih topik yang dekat dengan kebutuhan customer\nMulailah dari pertanyaan yang sering ditanyakan sebelum membeli. Misalnya harga, perbedaan layanan, cara memilih produk, proses pengerjaan, atau tips penggunaan.\n\nSatu artikel, satu fokus utama\nGunakan judul yang jelas dan isi yang benar-benar menjawab topik. Tambahkan heading agar artikel mudah dipindai.\n\nGunakan internal link\nHubungkan artikel ke halaman service, package, category, atau artikel lain yang relevan. Internal link membantu visitor menemukan informasi tambahan.\n\nOptimalkan metadata\nSetiap artikel sebaiknya memiliki SEO title, meta description, slug yang mudah dibaca, featured image, dan Open Graph image untuk social sharing.\n\nPerbarui artikel lama\nKonten yang sudah tidak relevan sebaiknya diperbarui. Artikel yang terawat lebih bermanfaat daripada banyak artikel yang dibiarkan usang.\n\nB-COM Blog CMS dirancang untuk mengelola status draft/published, category, featured image, SEO title, meta description, canonical URL, dan metadata social sharing.',
 'https://images.unsplash.com/photo-1455390582262-044cdead277a?q=80&w=1400&auto=format&fit=crop','published',now()-interval '7 days',
 'Blog untuk SEO Bisnis: Strategi Konten yang Praktis | B-COM',
 'Pelajari cara menggunakan blog untuk SEO bisnis melalui topik relevan, internal link, metadata, featured image, dan pembaruan konten.',
 'https://images.unsplash.com/photo-1455390582262-044cdead277a?q=80&w=1400&auto=format&fit=crop','id'),

((select id from c where slug='website'),
 'Website Undangan Pernikahan Digital: Fitur yang Sebaiknya Disiapkan',
 'fitur-website-undangan-pernikahan-digital',
 'Undangan digital modern dapat menggabungkan informasi acara, RSVP, guest management, maps, pesan personal, dan QR check-in.',
 'Website undangan pernikahan digital memudahkan pasangan membagikan informasi acara dalam satu link yang dapat dibuka melalui smartphone. Agar lebih berguna, website tidak hanya perlu terlihat indah tetapi juga mudah digunakan tamu.\n\nInformasi pasangan dan acara\nTampilkan nama pasangan, tanggal, waktu, lokasi, dan rangkaian acara dengan jelas. Countdown dapat membantu mengingatkan tamu.\n\nMaps dan petunjuk lokasi\nTautan maps mempermudah tamu menuju venue tanpa perlu menyalin alamat secara manual.\n\nGuest management dan personalized link\nSetiap tamu dapat memiliki nama dan link khusus. Pesan WhatsApp kemudian dapat dibuat otomatis menggunakan nama tamu dan URL invitation.\n\nRSVP\nRSVP membantu pasangan mengetahui estimasi tamu yang hadir, tidak hadir, atau masih belum memastikan.\n\nGallery dan love story\nBagian visual memberikan sentuhan personal, tetapi gambar harus tetap dioptimalkan supaya invitation cepat dibuka.\n\nQR check-in\nUntuk pengembangan lebih lanjut, QR unik dapat digunakan sebagai check-in dan pencatatan attendance.\n\nB-COM Wedding Module dirancang sebagai fitur khusus kategori Wedding Invitation dengan couple profile, events, guests, RSVP, personalized invitation, message generator, dan analytics dasar.',
 'https://images.unsplash.com/photo-1519225421980-715cb0215aed?q=80&w=1400&auto=format&fit=crop','published',now()-interval '8 days',
 'Fitur Website Undangan Pernikahan Digital Modern | B-COM',
 'Fitur penting undangan digital: RSVP, guest management, personalized link, maps, gallery, message generator, dan QR check-in.',
 'https://images.unsplash.com/photo-1519225421980-715cb0215aed?q=80&w=1400&auto=format&fit=crop','id')
on conflict(slug) do update set
 excerpt=excluded.excerpt, content=excluded.content, featured_image_url=excluded.featured_image_url,
 status='published', published_at=excluded.published_at, seo_title=excluded.seo_title,
 meta_description=excluded.meta_description, og_image_url=excluded.og_image_url;

-- One preview-only order per website category.
-- These rows are deliberately marked is_demo=true so Admin can inspect the full requirement shape safely.
insert into public.orders(order_number,package_id,customer_name,customer_email,customer_phone,status,subtotal,total_amount,currency,package_snapshot_json,requirement_json,is_demo)
select v.order_no,p.id,v.customer_name,v.email,v.phone,'submitted',p.normal_price,p.normal_price,'IDR',
 jsonb_build_object('package_name',p.name,'category',c.name,'tier',p.tier,'purchase_mode',p.purchase_mode),
 v.requirements::jsonb,true
from (values
 ('DEMO-2026-001','landing-page-basic','Demo Landing Page','demo.landing@example.com','081200000001','{"pic_name":"Alya Pratama","business_type":"Digital Marketing","language":"id","reference_url":"https://example.com/reference-landing","notes":"Demo order Landing Page untuk campaign jasa digital. Fokus CTA WhatsApp dan lead form.","brand_name":"GrowFast Digital","preferred_template":"SaaS Launch"}'),
 ('DEMO-2026-002','company-profile-basic','Demo Company Profile','demo.company@example.com','081200000002','{"pic_name":"Raka Wijaya","business_type":"IT Services","language":"id,en","reference_url":"https://example.com/reference-company","notes":"Demo company profile multi-page dengan About, Services, Portfolio, Clients, dan Contact.","brand_name":"Nusantara Tech","preferred_template":"Corporate Modern"}'),
 ('DEMO-2026-003','website-portfolio','Demo Portfolio','demo.portfolio@example.com','081200000003','{"pic_name":"Dina Maharani","business_type":"UI/UX Designer","language":"id,en","reference_url":"https://example.com/reference-portfolio","notes":"Demo portfolio personal dengan project gallery, profile, skills, dan contact.","brand_name":"Dina Studio","preferred_template":"Creative Portfolio"}'),
 ('DEMO-2026-004','restaurant-cafe-starter','Demo Restaurant Cafe','demo.cafe@example.com','081200000004','{"pic_name":"Fajar Aditya","business_type":"Coffee Shop","language":"id","reference_url":"https://example.com/reference-cafe","notes":"Demo website cafe dengan menu, gallery suasana, maps, jam buka, dan reservasi WhatsApp.","brand_name":"Kopi Sore Bekasi","preferred_template":"Coffee House"}'),
 ('DEMO-2026-005','travel-business','Demo Travel','demo.travel@example.com','081200000005','{"pic_name":"Nadia Putri","business_type":"Travel Agency","language":"id,en","reference_url":"https://example.com/reference-travel","notes":"Demo travel dengan paket wisata, destination cards, itinerary, testimonial, dan inquiry.","brand_name":"Jelajah Kita","preferred_template":"Tropical Escape"}'),
 ('DEMO-2026-006','product-catalog-business','Demo Product Catalog','demo.catalog@example.com','081200000006','{"pic_name":"Kevin Hartono","business_type":"Office Supplies B2B","language":"id","reference_url":"https://example.com/reference-catalog","notes":"Demo katalog B2B dengan kategori produk, detail spesifikasi, dan tombol request quotation.","brand_name":"Prima Supply","preferred_template":"Clean Catalog"}'),
 ('DEMO-2026-007','professional-services-business','Demo Professional Services','demo.services@example.com','081200000007','{"pic_name":"Sarah Amelia","business_type":"Business Consultant","language":"id,en","reference_url":"https://example.com/reference-consultant","notes":"Demo jasa konsultan dengan service detail, team, case studies, testimonials, dan lead form.","brand_name":"Summit Advisory","preferred_template":"Consultant Pro"}'),
 ('DEMO-2026-008','wedding-invitation-basic','Demo Wedding Invitation','demo.wedding@example.com','081200000008','{"pic_name":"Bagus & Alya","business_type":"Wedding Invitation","language":"id","reference_url":"https://example.com/reference-wedding","notes":"Demo wedding invitation dengan couple profile, event, maps, gallery, guest list, RSVP, dan message generator.","brand_name":"Bagus & Alya Wedding","preferred_template":"Elegant Wedding"}'),
 ('DEMO-2026-009','custom-website-solution','Demo Custom Website','demo.custom@example.com','081200000009','{"pic_name":"Andi Setiawan","business_type":"Custom Internal Application","language":"id,en","reference_url":"https://example.com/reference-custom","notes":"Demo request custom untuk customer portal dan workflow approval. Purchase mode menggunakan konsultasi/quotation.","brand_name":"PT Contoh Solusi","preferred_template":"Custom Business Solution"}')
) as v(order_no,package_slug,customer_name,email,phone,requirements)
join public.packages p on p.slug=v.package_slug
join public.website_categories c on c.id=p.category_id
on conflict(order_number) do update set
 package_id=excluded.package_id,customer_name=excluded.customer_name,customer_email=excluded.customer_email,
 customer_phone=excluded.customer_phone,subtotal=excluded.subtotal,total_amount=excluded.total_amount,
 package_snapshot_json=excluded.package_snapshot_json,requirement_json=excluded.requirement_json,is_demo=true;
