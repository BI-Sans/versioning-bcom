-- B-COM Final Local v2
-- Ready-made website templates (separate from visual themes) + public/admin access.

create table if not exists public.website_templates (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.website_categories(id) on delete set null,
  theme_id uuid references public.themes(id) on delete set null,
  name text not null,
  slug text not null unique,
  description text,
  preview_image_url text,
  demo_url text,
  tags text[] not null default '{}',
  is_featured boolean not null default false,
  is_premium boolean not null default false,
  status text not null default 'active' check(status in ('active','inactive','draft')),
  sort_order integer not null default 0,
  default_content_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.website_templates enable row level security;

drop policy if exists "templates public read" on public.website_templates;
create policy "templates public read" on public.website_templates for select using(status='active' or public.is_platform_admin());

drop policy if exists "templates admin write" on public.website_templates;
create policy "templates admin write" on public.website_templates for all using(public.is_platform_admin()) with check(public.is_platform_admin());

insert into public.website_templates(category_id,theme_id,name,slug,description,preview_image_url,tags,is_featured,is_premium,sort_order)
select c.id,t.id,v.name,v.slug,v.description,v.image,v.tags,v.featured,v.premium,v.sort_order
from (values
('landing-page','SaaS Launch','saas-launch','Modern SaaS landing page with strong conversion sections.','https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1400&auto=format&fit=crop',array['saas','startup','landing'],true,false,10),
('landing-page','Product Spotlight','product-spotlight','Product launch layout with visual storytelling and CTA blocks.','https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1400&auto=format&fit=crop',array['product','launch'],true,false,20),
('company-profile','Corporate Modern','corporate-modern','Professional company profile template for modern businesses.','https://images.unsplash.com/photo-1497366754035-f200968a6e72?q=80&w=1400&auto=format&fit=crop',array['corporate','business'],true,false,30),
('company-profile','Technology Enterprise','technology-enterprise','Enterprise technology profile with services, metrics and case studies.','https://images.unsplash.com/photo-1497366811353-6870744d04b2?q=80&w=1400&auto=format&fit=crop',array['technology','enterprise'],false,true,40),
('portfolio','Creative Portfolio','creative-portfolio','Visual portfolio for designers, freelancers and creators.','https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=1400&auto=format&fit=crop',array['portfolio','creative'],true,false,50),
('restaurant-cafe','Coffee House','coffee-house','Warm cafe template with menu, gallery and location sections.','https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=1400&auto=format&fit=crop',array['coffee','cafe','restaurant'],true,false,60),
('travel','Tropical Escape','tropical-escape','Travel package showcase with destinations, itinerary and CTA.','https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1400&auto=format&fit=crop',array['travel','tour'],true,false,70),
('product-catalog','Clean Catalog','clean-catalog','Clean product catalog template for B2B and retail showcases.','https://images.unsplash.com/photo-1441986300917-64674bd600d8?q=80&w=1400&auto=format&fit=crop',array['catalog','product'],false,false,80),
('professional-services','Consultant Pro','consultant-pro','Trust-focused service template for consulting and professional firms.','https://images.unsplash.com/photo-1521737711867-e3b97375f902?q=80&w=1400&auto=format&fit=crop',array['consulting','services'],false,false,90),
('wedding-invitation','Elegant Wedding','elegant-wedding','Elegant wedding invitation with couple story, event and RSVP.','https://images.unsplash.com/photo-1519225421980-715cb0215aed?q=80&w=1400&auto=format&fit=crop',array['wedding','elegant'],true,true,100)
) as v(category_slug,name,slug,description,image,tags,featured,premium,sort_order)
join public.website_categories c on c.slug=v.category_slug
left join lateral (
  select th.id from public.themes th where th.category_id=c.id and th.status='active' order by th.is_featured desc,th.created_at asc limit 1
) t on true
on conflict(slug) do update set preview_image_url=excluded.preview_image_url, description=excluded.description, tags=excluded.tags, is_featured=excluded.is_featured, is_premium=excluded.is_premium;
