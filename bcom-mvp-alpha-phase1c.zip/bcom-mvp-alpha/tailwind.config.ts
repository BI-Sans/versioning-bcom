import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        bcom: {
          navy: "#091F3B",
          yellow: "#FCD708",
          blue: "#183765",
          soft: "#F7F8FA"
        }
      }
    }
  },
  plugins: []
};

export default config;
