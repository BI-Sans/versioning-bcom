import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";

const MAX_FILE_SIZE = 5 * 1024 * 1024;
const ALLOWED = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);

function cleanName(name: string) {
  return name.toLowerCase().replace(/[^a-z0-9._-]+/g, "-").replace(/-+/g, "-").slice(-100);
}

export async function uploadTenantImage(input: {
  tenantId: string;
  websiteId: string;
  file: File;
  altText?: string;
  uploadedBy?: string | null;
}) {
  if (!ALLOWED.has(input.file.type)) throw new Error("Only JPG, PNG, WEBP, or GIF images are allowed.");
  if (input.file.size > MAX_FILE_SIZE) throw new Error("Maximum image size is 5 MB.");

  const supabase = createAdminClient();
  const safeName = cleanName(input.file.name || "image");
  const path = `${input.tenantId}/${input.websiteId}/${Date.now()}-${crypto.randomUUID().slice(0, 8)}-${safeName}`;
  const buffer = Buffer.from(await input.file.arrayBuffer());
  const { error: uploadError } = await supabase.storage.from("tenant-assets").upload(path, buffer, {
    contentType: input.file.type,
    upsert: false,
  });
  if (uploadError) throw new Error(uploadError.message);
  const { data: publicData } = supabase.storage.from("tenant-assets").getPublicUrl(path);
  const { data, error } = await supabase.from("media").insert({
    tenant_id: input.tenantId,
    website_id: input.websiteId,
    file_name: input.file.name,
    file_path: path,
    public_url: publicData.publicUrl,
    file_type: "image",
    mime_type: input.file.type,
    file_size: input.file.size,
    alt_text: input.altText || null,
    uploaded_by: input.uploadedBy || null,
  }).select("*").single();
  if (error) {
    await supabase.storage.from("tenant-assets").remove([path]);
    throw new Error(error.message);
  }
  return data;
}
