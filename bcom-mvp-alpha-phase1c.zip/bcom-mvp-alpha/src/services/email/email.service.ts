import "server-only";
import nodemailer from "nodemailer";
import { formatIDR } from "@/lib/utils";

function transporter() {
  if (!process.env.EMAIL_USER || !process.env.EMAIL_APP_PASSWORD) return null;
  return nodemailer.createTransport({
    service: "gmail",
    auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_APP_PASSWORD }
  });
}

export async function sendOrderNotification(input: { orderNumber: string; customerName: string; customerEmail: string; packageName: string; amount: number }) {
  const tx = transporter();
  if (!tx) return { skipped: true };
  const fromName = process.env.EMAIL_FROM_NAME || "B-COM";
  const adminEmail = process.env.ADMIN_NOTIFICATION_EMAIL || process.env.EMAIL_USER!;
  await Promise.allSettled([
    tx.sendMail({
      from: `${fromName} <${process.env.EMAIL_USER}>`, to: input.customerEmail,
      subject: `B-COM Order Confirmation - ${input.orderNumber}`,
      html: `<h2>Order berhasil diterima</h2><p>Halo ${input.customerName},</p><p>Terima kasih. Order <strong>${input.orderNumber}</strong> untuk paket <strong>${input.packageName}</strong> telah kami terima.</p><p>Nilai paket: <strong>${formatIDR(input.amount)}</strong> (belum termasuk PPN jika pajak diaktifkan).</p><p>Tim B-COM akan melakukan review requirement Anda.</p>`
    }),
    tx.sendMail({
      from: `${fromName} <${process.env.EMAIL_USER}>`, to: adminEmail,
      subject: `New B-COM Website Order - ${input.orderNumber}`,
      html: `<h2>New Website Order</h2><p>Customer: ${input.customerName}</p><p>Email: ${input.customerEmail}</p><p>Package: ${input.packageName}</p><p>Amount: ${formatIDR(input.amount)}</p>`
    })
  ]);
  return { sent: true };
}

export async function sendTestEmail(to: string) {
  const tx = transporter();
  if (!tx) throw new Error("EMAIL_USER / EMAIL_APP_PASSWORD belum dikonfigurasi");
  return tx.sendMail({
    from: `${process.env.EMAIL_FROM_NAME || "B-COM"} <${process.env.EMAIL_USER}>`,
    to,
    subject: "B-COM SMTP Test",
    html: "<h2>B-COM Email Connected</h2><p>Gmail SMTP + App Password berhasil digunakan oleh aplikasi.</p>"
  });
}

export async function sendCustomerPortalInvite(input: { customerName: string; customerEmail: string; actionLink: string; websiteName: string }) {
  const tx = transporter();
  if (!tx) return { skipped: true };
  const fromName = process.env.EMAIL_FROM_NAME || "B-COM";
  return tx.sendMail({
    from: `${fromName} <${process.env.EMAIL_USER}>`,
    to: input.customerEmail,
    subject: `B-COM Customer Portal Invitation - ${input.websiteName}`,
    html: `<h2>Website Anda sudah disiapkan</h2><p>Halo ${input.customerName},</p><p>Akun Customer Portal B-COM untuk <strong>${input.websiteName}</strong> telah dibuat.</p><p><a href="${input.actionLink}" style="display:inline-block;padding:12px 18px;background:#FCD708;color:#091F3B;text-decoration:none;border-radius:10px;font-weight:700">Activate Customer Portal</a></p><p>Link ini digunakan untuk mengaktifkan akun dan membuat password Anda. Setelah aktif, Anda dapat mengelola konten website melalui B-COM Customer Portal.</p>`
  });
}
