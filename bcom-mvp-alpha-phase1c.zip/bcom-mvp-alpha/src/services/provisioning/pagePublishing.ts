import "server-only";
import type { SupabaseClient } from "@supabase/supabase-js";

export async function publishPageDraft(supabase: SupabaseClient, pageId: string, websiteId: string, publishedBy?: string | null) {
  const { data: sections, error } = await supabase.from("page_sections").select("*").eq("page_id", pageId).eq("website_id", websiteId).order("sort_order");
  if (error) throw new Error(error.message);

  const snapshot = (sections || []).map((sec: any) => ({
    id: sec.id,
    section_type: sec.section_type,
    sort_order: sec.sort_order,
    variant: sec.variant,
    content_json: sec.content_json,
    settings_json: sec.settings_json,
    responsive_json: sec.responsive_json,
    is_visible: sec.is_visible
  }));

  const { data: page } = await supabase.from("pages").select("tenant_id").eq("id", pageId).eq("website_id", websiteId).single();
  if (!page) throw new Error("Page not found");

  const { data: last } = await supabase.from("page_versions").select("version_number").eq("page_id", pageId).order("version_number", { ascending: false }).limit(1).maybeSingle();
  const nextVersion = (last?.version_number || 0) + 1;
  await supabase.from("page_versions").insert({ tenant_id: page.tenant_id, website_id: websiteId, page_id: pageId, version_number: nextVersion, snapshot_json: snapshot, published_by: publishedBy || null });

  for (const sec of sections || []) {
    if (sec.draft_deleted) {
      const { error: deleteError } = await supabase.from("page_sections").delete().eq("id", sec.id);
      if (deleteError) throw new Error(deleteError.message);
      continue;
    }
    const { error: updateError } = await supabase.from("page_sections").update({
      variant: sec.draft_variant || sec.variant,
      content_json: sec.draft_content_json ?? sec.content_json,
      settings_json: sec.draft_settings_json ?? sec.settings_json,
      responsive_json: sec.draft_responsive_json ?? sec.responsive_json,
      is_visible: sec.draft_is_visible ?? sec.is_visible,
      draft_deleted: false,
      updated_at: new Date().toISOString()
    }).eq("id", sec.id);
    if (updateError) throw new Error(updateError.message);
  }

  const now = new Date().toISOString();
  const { error: pageError } = await supabase.from("pages").update({ status: "published", published_at: now, updated_at: now }).eq("id", pageId).eq("website_id", websiteId);
  if (pageError) throw new Error(pageError.message);
  return { version: nextVersion };
}
