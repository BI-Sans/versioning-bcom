import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export async function requireUser() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/admin/login");
  return user;
}

export async function requirePlatformAdmin() {
  const user = await requireUser();
  const supabase = await createClient();
  const { data } = await supabase.from("profiles").select("id,is_platform_admin,status").eq("auth_user_id", user.id).single();
  if (!data?.is_platform_admin || data.status !== "active") redirect("/admin/login?error=forbidden");
  return { user, profile: data };
}

export async function requireTenantUser() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/portal/login");
  const { data: profile } = await supabase.from("profiles").select("id,full_name,email,status").eq("auth_user_id", user.id).single();
  if (!profile || profile.status !== "active") redirect("/portal/login?error=forbidden");
  const { data: memberships } = await supabase.from("tenant_users").select("tenant_id,role_id,status,tenants(id,name,slug,status)").eq("user_id", profile.id).eq("status", "active");
  if (!memberships?.length) redirect("/portal/login?error=no-membership");
  return { user, profile, memberships };
}

export async function requireWebsiteAccess(websiteId: string) {
  const session = await requireTenantUser();
  const tenantIds = session.memberships.map((m: any) => m.tenant_id);
  const supabase = await createClient();
  const { data: website } = await supabase.from("websites").select("id,tenant_id,name,slug,status,default_language,category_id,theme_id").eq("id", websiteId).in("tenant_id", tenantIds).single();
  if (!website) redirect("/portal?error=website-access");
  return { ...session, website };
}
