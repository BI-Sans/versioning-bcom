import Link from "next/link";

export type TenantSection = {
  id: string;
  section_type: string;
  variant: string;
  sort_order: number;
  content_json: any;
  settings_json?: any;
  responsive_json?: any;
  is_visible: boolean;
  draft_variant?: string | null;
  draft_content_json?: any;
  draft_settings_json?: any;
  draft_responsive_json?: any;
  draft_is_visible?: boolean | null;
  draft_deleted?: boolean | null;
};

function sectionValue(section: TenantSection, mode: "published" | "draft") {
  if (mode === "draft") {
    return {
      variant: section.draft_variant || section.variant,
      content: section.draft_content_json ?? section.content_json ?? {},
      settings: section.draft_settings_json ?? section.settings_json ?? {},
      responsive: section.draft_responsive_json ?? section.responsive_json ?? {},
      visible: section.draft_deleted ? false : (section.draft_is_visible ?? section.is_visible)
    };
  }
  return {
    variant: section.variant,
    content: section.content_json || {},
    settings: section.settings_json || {},
    responsive: section.responsive_json || {},
    visible: section.is_visible
  };
}

function responsiveClasses(r: any) {
  const hideMobile = r?.mobile?.hidden ? "max-sm:hidden" : "";
  const hideDesktop = r?.desktop?.hidden ? "sm:hidden" : "";
  const align = r?.mobile?.align === "center" ? "max-sm:text-center" : r?.mobile?.align === "right" ? "max-sm:text-right" : "";
  const desktopAlign = r?.desktop?.align === "center" ? "sm:text-center" : r?.desktop?.align === "right" ? "sm:text-right" : "";
  return [hideMobile, hideDesktop, align, desktopAlign].filter(Boolean).join(" ");
}

function sectionPadding(r: any) {
  const py = Number(r?.desktop?.paddingY ?? 80);
  const mobilePy = Number(r?.mobile?.paddingY ?? 56);
  return { paddingTop: `clamp(${mobilePy}px, 7vw, ${py}px)`, paddingBottom: `clamp(${mobilePy}px, 7vw, ${py}px)` };
}

export function TenantSiteRenderer({
  sections,
  primary,
  secondary,
  mode = "published"
}: {
  sections: TenantSection[];
  primary: string;
  secondary: string;
  mode?: "published" | "draft";
}) {
  return (
    <main style={{ ["--tenant-primary" as any]: primary, ["--tenant-secondary" as any]: secondary }}>
      {sections
        .slice()
        .sort((a, b) => a.sort_order - b.sort_order)
        .map((section) => {
          const data = sectionValue(section, mode);
          if (!data.visible) return null;
          return <Section key={section.id} section={section} data={data} primary={primary} secondary={secondary} />;
        })}
    </main>
  );
}

function Section({ section, data, primary, secondary }: { section: TenantSection; data: any; primary: string; secondary: string }) {
  const c = data.content || {};
  const r = data.responsive || {};
  const variant = data.variant || "default";
  const classes = responsiveClasses(r);
  const paddingStyle = sectionPadding(r);
  const button = c.button_text && c.button_url ? (
    <Link href={c.button_url} className="mt-7 inline-flex rounded-xl px-5 py-3 font-bold" style={{ background: secondary, color: primary }}>
      {c.button_text}
    </Link>
  ) : null;

  if (section.section_type === "hero") {
    if (variant === "centered") return (
      <section className={`px-6 text-center ${classes}`} style={{ background: c.background || "#F7F8FA", ...paddingStyle }}>
        <div className="mx-auto max-w-4xl">
          <h1 className="text-4xl font-black md:text-6xl" style={{ color: primary }}>{c.title || "Your Website"}</h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-slate-600">{c.description}</p>{button}
        </div>
      </section>
    );
    if (variant === "full-background" && c.image_url) return (
      <section className={`relative min-h-[70vh] bg-cover bg-center px-6 ${classes}`} style={{ backgroundImage: `linear-gradient(rgba(9,31,59,.72),rgba(9,31,59,.72)),url(${c.image_url})`, ...paddingStyle }}>
        <div className="mx-auto max-w-6xl text-white"><h1 className="max-w-4xl text-4xl font-black md:text-6xl">{c.title || "Your Website"}</h1><p className="mt-5 max-w-2xl text-lg leading-8 text-white/80">{c.description}</p>{button}</div>
      </section>
    );
    if (variant === "bento") return (
      <section className={`px-6 ${classes}`} style={{ background: c.background || "#F7F8FA", ...paddingStyle }}>
        <div className="mx-auto grid max-w-6xl gap-5 lg:grid-cols-12">
          <div className="rounded-3xl bg-white p-8 shadow-sm lg:col-span-7"><h1 className="text-4xl font-black md:text-6xl" style={{ color: primary }}>{c.title || "Your Website"}</h1><p className="mt-5 max-w-2xl text-lg leading-8 text-slate-600">{c.description}</p>{button}</div>
          <div className="overflow-hidden rounded-3xl lg:col-span-5">{c.image_url ? <img src={c.image_url} alt={c.image_alt || ""} className="h-full min-h-72 w-full object-cover" /> : <div className="h-full min-h-72" style={{ background: secondary + "44" }} />}</div>
        </div>
      </section>
    );
    return (
      <section className={`px-6 ${classes}`} style={{ background: c.background || "#F7F8FA", ...paddingStyle }}>
        <div className="mx-auto grid max-w-6xl items-center gap-10 lg:grid-cols-2">
          <div><h1 className="text-4xl font-black md:text-6xl" style={{ color: primary }}>{c.title || "Your Website"}</h1><p className="mt-5 max-w-2xl text-lg leading-8 text-slate-600">{c.description}</p>{button}</div>
          {c.image_url ? <img src={c.image_url} alt={c.image_alt || ""} className="aspect-[4/3] w-full rounded-3xl object-cover" /> : <div className="aspect-[4/3] rounded-3xl" style={{ background: secondary + "33" }} />}
        </div>
      </section>
    );
  }

  if (section.section_type === "about") return (
    <section className={`px-6 ${classes}`} style={paddingStyle}>
      <div className={`mx-auto grid max-w-6xl items-center gap-10 ${variant === "centered" ? "text-center" : "lg:grid-cols-2"}`}>
        {c.image_url && variant !== "centered" && <img src={c.image_url} alt={c.image_alt || ""} className={`aspect-[4/3] w-full rounded-3xl object-cover ${variant === "image-right" ? "lg:order-2" : ""}`} />}
        <div className={variant === "centered" ? "mx-auto max-w-3xl" : ""}><h2 className="text-3xl font-black md:text-4xl" style={{ color: primary }}>{c.title || "About Us"}</h2><p className="mt-4 whitespace-pre-line leading-8 text-slate-600">{c.description}</p>{button}</div>
      </div>
    </section>
  );

  if (section.section_type === "services") {
    const items = Array.isArray(c.items) && c.items.length ? c.items : ["Service One", "Service Two", "Service Three"];
    if (variant === "list") return <section className={`bg-slate-50 px-6 ${classes}`} style={paddingStyle}><div className="mx-auto max-w-6xl"><h2 className="text-3xl font-black md:text-4xl" style={{ color: primary }}>{c.title || "Our Services"}</h2><div className="mt-8 divide-y divide-slate-200 border-y border-slate-200">{items.map((item: string, i: number) => <div key={`${item}-${i}`} className="flex gap-5 py-5"><span className="font-black" style={{ color: secondary }}>0{i + 1}</span><div className="font-bold" style={{ color: primary }}>{item}</div></div>)}</div></div></section>;
    return <section className={`bg-slate-50 px-6 ${classes}`} style={paddingStyle}><div className="mx-auto max-w-6xl"><h2 className="text-3xl font-black md:text-4xl" style={{ color: primary }}>{c.title || "Our Services"}</h2><p className="mt-3 max-w-2xl text-slate-600">{c.description}</p><div className={`mt-8 grid gap-4 ${variant === "icon-grid" ? "sm:grid-cols-2 lg:grid-cols-4" : "md:grid-cols-3"}`}>{items.map((item: string, i: number) => <div key={`${item}-${i}`} className="rounded-2xl border border-slate-200 bg-white p-6"><div className="h-2 w-10 rounded-full" style={{ background: secondary }} /><div className="mt-4 font-bold" style={{ color: primary }}>{item}</div></div>)}</div></div></section>;
  }

  if (section.section_type === "gallery") {
    const images = Array.isArray(c.images) && c.images.length ? c.images : c.image_url ? [c.image_url] : [];
    return <section className={`px-6 ${classes}`} style={paddingStyle}><div className="mx-auto max-w-6xl"><h2 className="text-3xl font-black md:text-4xl" style={{ color: primary }}>{c.title || "Gallery"}</h2><p className="mt-3 text-slate-600">{c.description}</p><div className={`mt-8 grid gap-4 ${variant === "masonry" ? "sm:grid-cols-2 lg:grid-cols-3" : "md:grid-cols-3"}`}>{images.map((src: string, i: number) => <img key={`${src}-${i}`} src={src} alt="" className={`w-full rounded-2xl object-cover ${variant === "masonry" && i % 2 ? "aspect-[4/5]" : "aspect-square"}`} />)}</div></div></section>;
  }

  if (section.section_type === "contact") return <section className={`px-6 ${classes}`} style={paddingStyle}><div className="mx-auto max-w-6xl rounded-3xl p-8 md:p-12" style={{ background: primary, color: "white" }}><h2 className="text-3xl font-black md:text-4xl">{c.title || "Contact"}</h2><p className="mt-4 max-w-2xl whitespace-pre-line text-white/75">{c.description}</p>{button}</div></section>;

  return <section className={`px-6 ${classes}`} style={paddingStyle}><div className="mx-auto max-w-6xl"><h2 className="text-3xl font-black" style={{ color: primary }}>{c.title || section.section_type}</h2><p className="mt-4 whitespace-pre-line text-slate-600">{c.description}</p>{button}</div></section>;
}
