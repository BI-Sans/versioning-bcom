"use client";
import { useMemo, useState } from "react";

type Guest={id:string;name:string;slug:string;access_token:string;phone?:string|null};
type Template={id:string;name:string;message_template:string};
export function WeddingMessageGenerator({guests,templates,coupleName,baseUrl}:{guests:Guest[];templates:Template[];coupleName:string;baseUrl:string}){
  const [guestId,setGuestId]=useState(guests[0]?.id||"");const [templateId,setTemplateId]=useState(templates[0]?.id||"");
  const guest=guests.find(g=>g.id===guestId)||guests[0];const template=templates.find(t=>t.id===templateId)||templates[0];
  const invitationUrl=guest?`${baseUrl}/i/${guest.slug}?t=${guest.access_token}`:"";
  const message=useMemo(()=>{if(!template||!guest)return "";return template.message_template.replaceAll("{{guest_name}}",guest.name).replaceAll("{{couple_name}}",coupleName||"The Couple").replaceAll("{{invitation_url}}",invitationUrl)},[template,guest,coupleName,invitationUrl]);
  async function copy(){if(message)await navigator.clipboard.writeText(message)}
  const wa=guest?.phone?`https://wa.me/${guest.phone.replace(/\D/g,"").replace(/^0/,"62")}?text=${encodeURIComponent(message)}`:`https://wa.me/?text=${encodeURIComponent(message)}`;
  return <div className="card p-6"><h2 className="text-xl font-black text-bcom-navy">Invitation Message Generator</h2><div className="mt-4 grid gap-4 md:grid-cols-2"><label><span className="label">Guest</span><select className="input" value={guestId} onChange={e=>setGuestId(e.target.value)}>{guests.map(g=><option key={g.id} value={g.id}>{g.name}</option>)}</select></label><label><span className="label">Template</span><select className="input" value={templateId} onChange={e=>setTemplateId(e.target.value)}>{templates.map(t=><option key={t.id} value={t.id}>{t.name}</option>)}</select></label></div><textarea readOnly className="input mt-4 min-h-64 whitespace-pre-wrap" value={message}/><div className="mt-4 flex flex-wrap gap-2"><button type="button" className="btn-primary" onClick={copy}>Copy Message</button><a href={wa} target="_blank" className="btn-secondary" rel="noreferrer">Open WhatsApp</a></div></div>
}
