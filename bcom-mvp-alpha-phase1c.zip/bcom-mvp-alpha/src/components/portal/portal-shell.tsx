import Link from "next/link";
import { Globe2, LayoutDashboard, LogOut, UserRound } from "lucide-react";
import { Logo } from "@/components/logo";
import { logout } from "@/app/admin/(auth)/login/actions";

export function PortalShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-slate-50 lg:grid lg:grid-cols-[250px_1fr]">
      <aside className="border-r border-slate-200 bg-white p-5">
        <Logo />
        <div className="mt-2 text-xs font-semibold uppercase tracking-wider text-slate-400">Customer Portal</div>
        <nav className="mt-8 space-y-1">
          <Link href="/portal" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-100"><LayoutDashboard size={18}/>Dashboard</Link>
          <Link href="/portal/websites" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-100"><Globe2 size={18}/>My Websites</Link>
          <Link href="/portal/account" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-100"><UserRound size={18}/>Account</Link>
        </nav>
        <form action={logout} className="mt-8"><button className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50"><LogOut size={18}/>Logout</button></form>
      </aside>
      <main className="p-5 md:p-8">{children}</main>
    </div>
  );
}
