import Image from "next/image";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <Image src="/branding/bcom-logo.png" alt="B-COM logo" width={44} height={44} className="rounded-xl" />
      {!compact && (
        <div>
          <div className="font-bold tracking-tight text-bcom-navy">B-COM</div>
          <div className="text-[11px] text-slate-500">Your Technology Support Partner</div>
        </div>
      )}
    </div>
  );
}
