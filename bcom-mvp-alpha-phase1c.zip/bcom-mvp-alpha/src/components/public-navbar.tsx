import Link from "next/link";
import { Logo } from "@/components/logo";

export function PublicNavbar() {
  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/80 bg-white/90 backdrop-blur">
      <div className="container-bcom flex h-20 items-center justify-between">
        <Link href="/"><Logo /></Link>
        <nav className="hidden items-center gap-7 text-sm font-medium text-slate-700 md:flex">
          <Link href="/#services">Services</Link>
          <Link href="/#packages">Packages</Link>
          <Link href="/#about">About</Link>
          <Link href="/admin/login" className="btn-outline">Admin</Link>
          <Link href="/#packages" className="btn-primary">Get Started</Link>
        </nav>
        <Link href="/#packages" className="btn-primary md:hidden">Mulai</Link>
      </div>
    </header>
  );
}
