import Link from "next/link";
import { Logo } from "@/components/logo";
import { LayoutDashboard, Package, ShoppingCart, Users, Globe2, Settings, Palette, LogOut, Shapes, PanelsTopLeft } from "lucide-react";
import { logout } from "@/app/admin/(auth)/login/actions";

const nav = [
  ["Dashboard", "/admin", LayoutDashboard],
  ["Orders", "/admin/orders", ShoppingCart],
  ["Packages", "/admin/packages", Package],
  ["Customers", "/admin/customers", Users],
  ["Websites", "/admin/websites", Globe2],
  ["Categories", "/admin/categories", Shapes],
  ["Themes", "/admin/themes", Palette],
  ["Landing Page", "/admin/landing-page", PanelsTopLeft],
  ["Settings", "/admin/settings", Settings]
] as const;

export function AdminShell({ children }: { children: React.ReactNode }) {
  return <div className="min-h-screen bg-slate-50 lg:grid lg:grid-cols-[250px_1fr]"><aside className="border-r border-slate-200 bg-white p-5"><Logo/><div className="mt-2 text-xs font-semibold uppercase tracking-wider text-slate-400">Admin Portal</div><nav className="mt-8 space-y-1">{nav.map(([label,href,Icon]) => <Link key={href} href={href} className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-700 hover:bg-slate-100"><Icon size={18}/>{label}</Link>)}</nav><form action={logout} className="mt-8"><button className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50"><LogOut size={18}/>Logout</button></form></aside><main className="p-5 md:p-8">{children}</main></div>;
}
