import { NextResponse } from "next/server";
import { sendTestEmail } from "@/services/email/email.service";
import { requirePlatformAdmin } from "@/services/auth/guards";

export async function POST(request: Request) {
  try {
    await requirePlatformAdmin();
    const body = await request.json();
    const to = body?.to || process.env.ADMIN_NOTIFICATION_EMAIL;
    if (!to) return NextResponse.json({ error: "Recipient required" }, { status: 400 });
    await sendTestEmail(to);
    return NextResponse.json({ ok: true });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Failed" }, { status: 500 });
  }
}
