import Link from "next/link";
import { PublicNavbar } from "@/components/public-navbar";
import { Logo } from "@/components/logo";
import { formatIDR } from "@/lib/utils";
import { createClient } from "@/lib/supabase/server";
import { ArrowRight, CheckCircle2, Code2, Database, LifeBuoy, Sparkles } from "lucide-react";

export const dynamic = "force-dynamic";


async function getLandingSections() {
  try {
    const supabase = await createClient();
    const { data } = await supabase.from("landing_sections").select("section_key,content_json,is_visible").eq("is_visible", true).order("sort_order");
    return Object.fromEntries((data ?? []).map((row: any) => [row.section_key, row.content_json ?? {}]));
  } catch {
    return {} as Record<string, any>;
  }
}

async function getPackages() {
  try {
    const supabase = await createClient();
    const { data } = await supabase
      .from("packages")
      .select("id,name,slug,short_description,normal_price,promo_price,promo_start,promo_end,is_featured,show_on_homepage,status,website_categories(name)")
      .eq("status", "active")
      .eq("show_on_homepage", true)
      .order("sort_order")
      .limit(6);
    return data ?? [];
  } catch {
    return [];
  }
}

function activePrice(pkg: any) {
  const now = new Date();
  const start = pkg.promo_start ? new Date(pkg.promo_start) : null;
  const end = pkg.promo_end ? new Date(pkg.promo_end) : null;
  const promoActive = pkg.promo_price && (!start || start <= now) && (!end || end >= now);
  return { price: promoActive ? pkg.promo_price : pkg.normal_price, promoActive };
}

export default async function Home() {
  const [packages, cms] = await Promise.all([getPackages(), getLandingSections()]);
  const announcement = cms.announcement ?? {};
  const hero = cms.hero ?? {};
  const services = cms.services ?? {};
  const about = cms.about ?? {};
  return (
    <main>
      <PublicNavbar />
      <section className="overflow-hidden bg-gradient-to-b from-slate-50 to-white py-20 md:py-28">
        <div className="container-bcom grid items-center gap-12 lg:grid-cols-2">
          <div>
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-bcom-yellow/50 bg-yellow-50 px-3 py-1 text-sm font-semibold text-bcom-navy">
              <Sparkles size={16} /> {announcement.text || "Established in 2022"}
            </div>
            <h1 className="max-w-3xl text-4xl font-black leading-tight tracking-tight text-bcom-navy md:text-6xl">
              {hero.title || "Build. Manage. Grow with Technology."}
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-600">
              {hero.description || "B-COM membantu bisnis membangun website, custom web application, business management system, automation, dan solusi software yang praktis dengan dukungan berkelanjutan."}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="#packages" className="btn-primary gap-2">{hero.primary_cta || "Lihat Paket"} <ArrowRight size={18} /></Link>
              <a href="mailto:bekasi.computer22@gmail.com" className="btn-outline">{hero.secondary_cta || "Konsultasi"}</a>
            </div>
            <p className="mt-6 text-sm text-slate-500">Operational 09:00–18:00 WIB · 24/7 Chat Availability</p>
          </div>
          <div className="relative mx-auto w-full max-w-xl">
            <div className="absolute inset-10 rounded-[3rem] bg-bcom-yellow/25 blur-3xl" />
            <div className="card relative p-8 md:p-10">
              <Logo />
              <div className="mt-8 grid gap-4 sm:grid-cols-2">
                {[
                  [Code2, "Website Development", "Responsive, dynamic, scalable"],
                  [Database, "Business Systems", "Dashboard & management tools"],
                  [Sparkles, "Custom Applications", "Built for your workflow"],
                  [LifeBuoy, "Maintenance", "Support & improvements"]
                ].map(([Icon, title, desc]: any) => (
                  <div key={title} className="rounded-2xl bg-slate-50 p-5">
                    <Icon className="text-bcom-navy" />
                    <div className="mt-3 font-bold text-bcom-navy">{title}</div>
                    <div className="mt-1 text-sm text-slate-500">{desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="services" className="py-20">
        <div className="container-bcom">
          <div className="max-w-2xl">
            <div className="text-sm font-bold uppercase tracking-widest text-bcom-blue">{services.eyebrow || "Our Services"}</div>
            <h2 className="mt-3 text-3xl font-black text-bcom-navy md:text-4xl">{services.title || "Technology solutions that support your business."}</h2>
          </div>
          <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
            {(services.items || ["Website Development", "Custom Web Application", "Business Management System", "Maintenance & Support", "Dashboard & Internal Tools", "Automation Solutions", "Backend & Database", "Deployment & Cloud Setup"]).map((item: string) => (
              <div key={item} className="card p-6"><CheckCircle2 className="text-bcom-blue" /><h3 className="mt-4 font-bold text-bcom-navy">{item}</h3></div>
            ))}
          </div>
        </div>
      </section>

      <section id="packages" className="bg-slate-50 py-20">
        <div className="container-bcom">
          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
            <div>
              <div className="text-sm font-bold uppercase tracking-widest text-bcom-blue">Website Packages</div>
              <h2 className="mt-3 text-3xl font-black text-bcom-navy md:text-4xl">Start with a package that fits.</h2>
            </div>
            <div className="text-sm text-slate-500">Harga pada card belum termasuk PPN.</div>
          </div>
          <div className="mt-10 grid gap-6 lg:grid-cols-3">
            {packages.length ? packages.map((pkg: any) => {
              const { price, promoActive } = activePrice(pkg);
              return (
                <div key={pkg.id} className={`card relative p-7 ${pkg.is_featured ? "ring-2 ring-bcom-yellow" : ""}`}>
                  {promoActive && <span className="absolute right-5 top-5 rounded-full bg-bcom-yellow px-3 py-1 text-xs font-bold text-bcom-navy">PROMO</span>}
                  <div className="text-xs font-semibold uppercase tracking-wider text-slate-500">{pkg.website_categories?.name ?? "Website"}</div>
                  <h3 className="mt-2 text-2xl font-black text-bcom-navy">{pkg.name}</h3>
                  <p className="mt-3 min-h-12 text-sm leading-6 text-slate-500">{pkg.short_description}</p>
                  <div className="mt-6">
                    {promoActive && <div className="text-sm text-slate-400 line-through">{formatIDR(pkg.normal_price)}</div>}
                    <div className="text-4xl font-black tracking-tight text-bcom-navy">{formatIDR(price)}</div>
                    <div className="mt-1 text-xs text-slate-500">belum termasuk PPN</div>
                  </div>
                  <Link href={`/order/${pkg.slug}`} className="btn-primary mt-7 w-full">Pesan Sekarang</Link>
                </div>
              );
            }) : (
              <div className="card col-span-full p-8 text-center text-slate-500">Package belum tersedia. Jalankan seed Supabase untuk melihat package demo.</div>
            )}
          </div>
        </div>
      </section>

      <section id="about" className="py-20">
        <div className="container-bcom grid gap-10 lg:grid-cols-2">
          <div>
            <div className="text-sm font-bold uppercase tracking-widest text-bcom-blue">{about.eyebrow || "About B-COM"}</div>
            <h2 className="mt-3 text-3xl font-black text-bcom-navy">{about.title || "Your Technology Support Partner."}</h2>
          </div>
          <div className="space-y-4 text-slate-600">
            <p>{about.description || "B-COM (Bekasi Computer) adalah technology solutions partner yang berfokus pada software & web technology solutions."}</p>
            <p>Jl. P. Tidore 8 No.18, RT.002/RW.007, Aren Jaya, Bekasi Timur, Kota Bekasi, Jawa Barat 17111.</p>
            <p>Email: bekasi.computer22@gmail.com · WhatsApp: 0857-8101-0372</p>
          </div>
        </div>
      </section>
      <footer className="bg-bcom-navy py-10 text-white"><div className="container-bcom flex flex-col gap-4 md:flex-row md:items-center md:justify-between"><Logo /><div className="text-sm text-slate-300">© 2026 B-COM. Your Technology Support Partner.</div></div></footer>
    </main>
  );
}
