"use server";
import { redirect } from "next/navigation";
import { requirePlatformAdmin } from "@/services/auth/guards";
import { provisionWebsiteFromOrder } from "@/services/provisioning/provisionWebsite";
export async function approveAndProvision(fd: FormData) {
  await requirePlatformAdmin();
  const id = String(fd.get("order_id") || "");
  if (!id) throw new Error("Order ID missing");
  await provisionWebsiteFromOrder(id);
  redirect(`/admin/orders/${id}?created=1`);
}
