import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { formatIDR } from "@/lib/utils";
import { approveAndProvision } from "./actions";

export const dynamic = "force-dynamic";
export default async function OrderDetail({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ created?: string }> }) {
  const { id } = await params;
  const { created } = await searchParams;
  const s = await createClient();
  const { data: order } = await s.from("orders").select("*,packages(name,website_categories(name)),tenants(name,slug)").eq("id", id).single();
  if (!order) notFound();
  const req: any = order.requirement_json || {};
  return <div className="max-w-5xl"><div className="flex flex-col justify-between gap-4 md:flex-row md:items-start"><div><div className="text-sm text-slate-500">Order</div><h1 className="text-3xl font-black text-bcom-navy">{order.order_number}</h1><div className="mt-2 inline-block rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold">{order.status}</div></div>{order.tenant_id ? <Link href={`/sites/${order.tenants?.slug}`} target="_blank" className="btn-secondary">Open Website</Link> : <form action={approveAndProvision}><input type="hidden" name="order_id" value={order.id}/><button className="btn-primary">Approve & Create Website</button></form>}</div>{created&&<div className="mt-6 rounded-xl bg-green-50 p-4 text-sm font-medium text-green-800">Website provisioned successfully.</div>}<div className="mt-7 grid gap-5 lg:grid-cols-3"><section className="card p-6 lg:col-span-2"><h2 className="text-xl font-black text-bcom-navy">Customer & Requirement</h2><dl className="mt-5 grid gap-4 sm:grid-cols-2"><Item k="Customer" v={order.customer_name}/><Item k="Email" v={order.customer_email}/><Item k="WhatsApp" v={order.customer_phone}/><Item k="PIC" v={req.pic_name}/><Item k="Business Type" v={req.business_type}/><Item k="Language" v={req.language}/><Item k="Reference" v={req.reference_url}/><Item k="Notes" v={req.notes}/></dl></section><aside className="card p-6"><div className="text-sm text-slate-500">Package</div><div className="mt-1 font-black text-bcom-navy">{order.packages?.name}</div><div className="mt-1 text-xs text-slate-400">{order.packages?.website_categories?.name}</div><div className="mt-6 text-sm text-slate-500">Order Total</div><div className="text-3xl font-black text-bcom-navy">{formatIDR(order.total_amount)}</div><div className="mt-1 text-xs text-slate-500">MVP Alpha: payment manual/simulated.</div>{order.tenants&&<div className="mt-6 rounded-xl bg-slate-50 p-4 text-sm"><div className="font-semibold">Provisioned Tenant</div><div className="mt-1 text-slate-500">{order.tenants.name}</div><div className="text-slate-500">/sites/{order.tenants.slug}</div></div>}</aside></div></div>;
}
function Item({k,v}:{k:string;v:any}){return <div><dt className="text-xs font-semibold uppercase tracking-wide text-slate-400">{k}</dt><dd className="mt-1 break-words text-sm text-slate-700">{v||"-"}</dd></div>}
