"use server";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { requirePlatformAdmin } from "@/services/auth/guards";
const schema=z.object({name:z.string().min(2),slug:z.string().regex(/^[a-z0-9-]+$/),category_id:z.string().uuid(),description:z.string().optional(),primary:z.string().regex(/^#[0-9A-Fa-f]{6}$/),secondary:z.string().regex(/^#[0-9A-Fa-f]{6}$/),heading:z.string().min(1),body:z.string().min(1)});
export async function createTheme(fd:FormData){await requirePlatformAdmin();const p=schema.parse(Object.fromEntries(fd.entries()));const s=await createClient();const {error}=await s.from("themes").insert({name:p.name,slug:p.slug,category_id:p.category_id,description:p.description,status:"active",tokens_json:{colors:{primary:p.primary,secondary:p.secondary},typography:{heading:p.heading,body:p.body}}});if(error)throw new Error(error.message);revalidatePath("/admin/themes")}
