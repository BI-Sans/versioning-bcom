"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requirePlatformAdmin } from "@/services/auth/guards";
import { uploadTenantImage } from "@/services/media/media.service";
export async function uploadAdminMedia(websiteId:string,fd:FormData){const {profile}=await requirePlatformAdmin();const s=await createClient();const {data:w}=await s.from("websites").select("id,tenant_id").eq("id",websiteId).single();if(!w)throw new Error("Website not found");const file=fd.get("file");if(!(file instanceof File)||file.size===0)throw new Error("Please select an image.");await uploadTenantImage({tenantId:w.tenant_id,websiteId,file,altText:String(fd.get("alt_text")||""),uploadedBy:profile.id});revalidatePath(`/admin/websites/${websiteId}/media`)}
