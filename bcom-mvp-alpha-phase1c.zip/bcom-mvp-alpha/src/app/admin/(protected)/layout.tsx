import { AdminShell } from "@/components/admin-shell";
import { requirePlatformAdmin } from "@/services/auth/guards";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requirePlatformAdmin();
  return <AdminShell>{children}</AdminShell>;
}
