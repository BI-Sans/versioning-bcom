import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

export default async function AdminDashboard() {
  const supabase = await createClient();
  const [orders, packages, websites, tenants] = await Promise.all([
    supabase.from("orders").select("id", { count: "exact", head: true }),
    supabase.from("packages").select("id", { count: "exact", head: true }),
    supabase.from("websites").select("id", { count: "exact", head: true }),
    supabase.from("tenants").select("id", { count: "exact", head: true })
  ]);
  const cards = [["Orders",orders.count],["Packages",packages.count],["Websites",websites.count],["Customers",tenants.count]];
  return <div><h1 className="text-3xl font-black text-bcom-navy">Dashboard</h1><p className="mt-2 text-slate-500">B-COM MVP Alpha operational overview.</p><div className="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-4">{cards.map(([label,value]) => <div key={String(label)} className="card p-6"><div className="text-sm text-slate-500">{label}</div><div className="mt-2 text-4xl font-black text-bcom-navy">{value ?? 0}</div></div>)}</div></div>;
}
