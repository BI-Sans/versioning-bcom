"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { requirePlatformAdmin } from "@/services/auth/guards";

const schema=z.object({name:z.string().min(2),slug:z.string().regex(/^[a-z0-9-]+$/),short_description:z.string().optional(),category_id:z.string().uuid(),pricing_type:z.string(),normal_price:z.coerce.number().min(0),promo_price:z.union([z.coerce.number().min(0),z.literal("")]).optional(),show_on_homepage:z.boolean(),is_featured:z.boolean()});
export async function createPackage(fd:FormData){await requirePlatformAdmin();const raw=Object.fromEntries(fd.entries());const parsed=schema.parse({...raw,show_on_homepage:fd.get("show_on_homepage")==="on",is_featured:fd.get("is_featured")==="on"});const supabase=await createClient();const {error}=await supabase.from("packages").insert({name:parsed.name,slug:parsed.slug,short_description:parsed.short_description,category_id:parsed.category_id,pricing_type:parsed.pricing_type,normal_price:parsed.normal_price,promo_price:parsed.promo_price===""?null:parsed.promo_price,show_on_homepage:parsed.show_on_homepage,is_featured:parsed.is_featured,status:"active"});if(error)throw new Error(error.message);revalidatePath("/");revalidatePath("/admin/packages");redirect("/admin/packages")}
