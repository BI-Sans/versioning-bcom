"use server";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { requirePlatformAdmin } from "@/services/auth/guards";
const schema=z.object({name:z.string().min(2),slug:z.string().regex(/^[a-z0-9-]+$/),description:z.string().optional()});
export async function createCategory(fd:FormData){await requirePlatformAdmin();const parsed=schema.parse(Object.fromEntries(fd.entries()));const s=await createClient();const {error}=await s.from("website_categories").insert({...parsed,status:"active"});if(error)throw new Error(error.message);revalidatePath("/admin/categories")}
