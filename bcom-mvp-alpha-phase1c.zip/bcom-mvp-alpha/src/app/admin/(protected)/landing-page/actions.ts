"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requirePlatformAdmin } from "@/services/auth/guards";
export async function updateLandingSection(id:string,fd:FormData){
  await requirePlatformAdmin();
  const s=await createClient();
  const {data:current}=await s.from("landing_sections").select("content_json").eq("id",id).single();
  const content={...(current?.content_json||{}),eyebrow:String(fd.get("eyebrow")||""),title:String(fd.get("title")||""),description:String(fd.get("description")||""),text:String(fd.get("text")||""),primary_cta:String(fd.get("primary_cta")||""),secondary_cta:String(fd.get("secondary_cta")||"")};
  const {error}=await s.from("landing_sections").update({content_json:content,is_visible:fd.get("is_visible")==="on",updated_at:new Date().toISOString(),published_at:new Date().toISOString()}).eq("id",id);
  if(error)throw new Error(error.message);
  revalidatePath("/");revalidatePath("/admin/landing-page");
}
