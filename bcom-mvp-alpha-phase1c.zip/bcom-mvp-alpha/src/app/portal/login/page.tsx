import { Logo } from "@/components/logo";
import { portalLogin } from "./actions";

export default async function PortalLogin({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const { error } = await searchParams;
  return (
    <main className="grid min-h-screen place-items-center bg-slate-50 p-5">
      <div className="card w-full max-w-md p-8">
        <Logo />
        <div className="mt-8 text-xs font-bold uppercase tracking-widest text-bcom-blue">Customer Portal</div>
        <h1 className="mt-2 text-3xl font-black text-bcom-navy">Sign in</h1>
        <p className="mt-2 text-sm text-slate-500">Manage your B-COM website, content, media, and brand.</p>
        {error && <div className="mt-5 rounded-xl bg-red-50 p-3 text-sm text-red-700">{decodeURIComponent(error)}</div>}
        <form action={portalLogin} className="mt-6 space-y-4">
          <label><span className="label">Email</span><input name="email" type="email" required className="input" /></label>
          <label><span className="label">Password</span><input name="password" type="password" required className="input" /></label>
          <button className="btn-primary w-full">Sign In</button>
        </form>
      </div>
    </main>
  );
}
