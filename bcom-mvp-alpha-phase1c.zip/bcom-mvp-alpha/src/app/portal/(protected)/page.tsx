import Link from "next/link";
import { requireTenantUser } from "@/services/auth/guards";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";
export default async function PortalDashboard() {
  const { profile, memberships } = await requireTenantUser();
  const tenantIds = memberships.map((m: any) => m.tenant_id);
  const supabase = await createClient();
  const { data: websites } = await supabase.from("websites").select("id,name,slug,status,tenant_id").in("tenant_id", tenantIds).order("created_at", { ascending: false });
  return <div><div className="text-sm text-slate-500">Welcome, {profile.full_name || profile.email}</div><h1 className="mt-1 text-3xl font-black text-bcom-navy">Customer Dashboard</h1><div className="mt-7 grid gap-4 md:grid-cols-2 xl:grid-cols-3">{(websites ?? []).map((w:any)=><div className="card p-5" key={w.id}><div className="text-xs uppercase tracking-wider text-slate-400">Website</div><div className="mt-1 text-xl font-black text-bcom-navy">{w.name}</div><div className="mt-1 text-sm text-slate-500">/sites/{w.slug}</div><div className="mt-4 flex gap-2"><Link className="btn-primary text-sm" href={`/portal/websites/${w.id}`}>Manage</Link><Link className="btn-outline text-sm" href={`/sites/${w.slug}`} target="_blank">Open</Link></div></div>)}</div></div>;
}
