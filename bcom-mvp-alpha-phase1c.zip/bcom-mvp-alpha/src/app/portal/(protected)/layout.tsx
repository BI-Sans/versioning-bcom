import { PortalShell } from "@/components/portal/portal-shell";
import { requireTenantUser } from "@/services/auth/guards";

export default async function PortalLayout({ children }: { children: React.ReactNode }) {
  await requireTenantUser();
  return <PortalShell>{children}</PortalShell>;
}
