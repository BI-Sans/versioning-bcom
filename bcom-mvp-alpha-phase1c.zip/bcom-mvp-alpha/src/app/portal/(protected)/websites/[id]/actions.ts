"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
import { requireWebsiteAccess } from "@/services/auth/guards";
const color=z.string().regex(/^#[0-9A-Fa-f]{6}$/);
function slugify(v:string){return v.toLowerCase().trim().replace(/[^a-z0-9\s-]/g,"").replace(/\s+/g,"-").replace(/-+/g,"-");}

export async function updateBrandKit(websiteId:string,fd:FormData){const {website}=await requireWebsiteAccess(websiteId);const p=z.object({primary_color:color,secondary_color:color,accent_color:color.optional().or(z.literal("")),heading_font:z.string().min(1),body_font:z.string().min(1)}).parse(Object.fromEntries(fd.entries()));const s=await createClient();const {error}=await s.from("brand_kits").upsert({tenant_id:website.tenant_id,website_id:websiteId,primary_color:p.primary_color,secondary_color:p.secondary_color,accent_color:p.accent_color||null,heading_font:p.heading_font,body_font:p.body_font},{onConflict:"website_id"});if(error)throw new Error(error.message);revalidatePath(`/portal/websites/${websiteId}`);revalidatePath(`/sites/${website.slug}`)}

export async function createPage(websiteId:string,fd:FormData){
  const {website}=await requireWebsiteAccess(websiteId);const s=await createClient();const name=String(fd.get("name")||"").trim();const slug=slugify(String(fd.get("slug")||name));if(!name)throw new Error("Page name is required");
  const {data:last}=await s.from("pages").select("sort_order").eq("website_id",websiteId).order("sort_order",{ascending:false}).limit(1).maybeSingle();
  const {data:page,error}=await s.from("pages").insert({tenant_id:website.tenant_id,website_id:websiteId,name,slug,status:"draft",sort_order:(last?.sort_order||0)+1,is_homepage:false}).select("id").single();if(error||!page)throw new Error(error?.message||"Failed to create page");
  const initial={title:name,description:`Welcome to the ${name} page.`};
  await s.from("page_sections").insert({tenant_id:website.tenant_id,website_id:websiteId,page_id:page.id,section_type:"hero",variant:"centered",draft_variant:"centered",sort_order:1,content_json:initial,draft_content_json:initial,is_visible:false,draft_is_visible:true,draft_deleted:false});
  revalidatePath(`/portal/websites/${websiteId}`);redirect(`/portal/websites/${websiteId}/pages/${page.id}`);
}

export async function deletePage(websiteId:string,pageId:string){
  const {website}=await requireWebsiteAccess(websiteId);const s=await createClient();const {data:p}=await s.from("pages").select("is_homepage").eq("id",pageId).eq("website_id",websiteId).single();if(!p)throw new Error("Page not found");if(p.is_homepage)throw new Error("Homepage cannot be deleted");
  const {error}=await s.from("pages").delete().eq("id",pageId).eq("website_id",websiteId);if(error)throw new Error(error.message);revalidatePath(`/portal/websites/${websiteId}`);revalidatePath(`/sites/${website.slug}`);
}
