import { createClient } from "@/lib/supabase/server";
import { requireWebsiteAccess } from "@/services/auth/guards";
import { TenantSiteRenderer } from "@/components/tenant-site-renderer";
export const dynamic="force-dynamic";
export default async function DraftPreview({params}:{params:Promise<{id:string,pageId:string}>}){
  const {id,pageId}=await params;await requireWebsiteAccess(id);const s=await createClient();
  const [{data:web},{data:brand},{data:theme},{data:page},{data:sections}]=await Promise.all([
    s.from("websites").select("id,name,slug,theme_id").eq("id",id).single(),
    s.from("brand_kits").select("*").eq("website_id",id).maybeSingle(),
    s.from("websites").select("themes(tokens_json)").eq("id",id).single(),
    s.from("pages").select("id,name,slug,status").eq("id",pageId).eq("website_id",id).single(),
    s.from("page_sections").select("*").eq("page_id",pageId).order("sort_order")
  ]);
  if(!web||!page)return <div className="p-10">Preview not found.</div>;
  const tokens:any=(theme as any)?.themes?.tokens_json||{};const primary=brand?.primary_color||tokens.colors?.primary||"#091F3B";const secondary=brand?.secondary_color||tokens.colors?.secondary||"#FCD708";
  return <div><div className="sticky top-0 z-50 flex items-center justify-between border-b border-amber-200 bg-amber-50 px-4 py-2 text-sm"><strong>Draft Preview · {page.name}</strong><span>Changes here are not live until Publish.</span></div><TenantSiteRenderer sections={(sections||[]) as any} primary={primary} secondary={secondary} mode="draft"/></div>;
}
