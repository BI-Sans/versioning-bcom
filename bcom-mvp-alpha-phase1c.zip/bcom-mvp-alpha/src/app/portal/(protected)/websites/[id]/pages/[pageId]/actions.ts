"use server";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireWebsiteAccess } from "@/services/auth/guards";
import { publishPageDraft } from "@/services/provisioning/pagePublishing";

function contentFromForm(fd: FormData) {
  return {
    title: String(fd.get("title") || ""),
    description: String(fd.get("description") || ""),
    image_url: String(fd.get("image_url") || ""),
    image_alt: String(fd.get("image_alt") || ""),
    button_text: String(fd.get("button_text") || ""),
    button_url: String(fd.get("button_url") || ""),
    items: String(fd.get("items") || "").split("\n").map(v => v.trim()).filter(Boolean)
  };
}
function responsiveFromForm(fd: FormData) {
  return {
    desktop: { align: String(fd.get("desktop_align") || "left"), paddingY: Number(fd.get("desktop_padding") || 80), hidden: fd.get("hide_desktop") === "on" },
    tablet: { align: String(fd.get("tablet_align") || "left"), paddingY: Number(fd.get("tablet_padding") || 64) },
    mobile: { align: String(fd.get("mobile_align") || "left"), paddingY: Number(fd.get("mobile_padding") || 56), hidden: fd.get("hide_mobile") === "on" }
  };
}
function refresh(websiteId:string,pageId:string,slug:string){
  revalidatePath(`/portal/websites/${websiteId}/pages/${pageId}`);
  revalidatePath(`/portal/websites/${websiteId}/preview/${pageId}`);
  revalidatePath(`/sites/${slug}`);
}

export async function updateSection(websiteId:string,pageId:string,sectionId:string,fd:FormData){
  const {website}=await requireWebsiteAccess(websiteId);const s=await createClient();
  const {error}=await s.from("page_sections").update({
    draft_content_json:contentFromForm(fd),
    draft_variant:String(fd.get("variant")||"default"),
    draft_is_visible:fd.get("is_visible")==="on",
    draft_responsive_json:responsiveFromForm(fd),
    updated_at:new Date().toISOString()
  }).eq("id",sectionId).eq("website_id",websiteId).eq("page_id",pageId);
  if(error)throw new Error(error.message);refresh(websiteId,pageId,website.slug);
}

export async function addSection(websiteId:string,pageId:string,fd:FormData){
  const {website}=await requireWebsiteAccess(websiteId);const s=await createClient();const type=String(fd.get("section_type")||"content");
  const {data:last}=await s.from("page_sections").select("sort_order").eq("page_id",pageId).order("sort_order",{ascending:false}).limit(1).maybeSingle();
  const title=type.replace(/-/g," ").replace(/\b\w/g,c=>c.toUpperCase());
  const initial={title,description:"Edit this section from the B-COM builder."};
  const responsive={desktop:{align:"left",paddingY:80,hidden:false},tablet:{align:"left",paddingY:64},mobile:{align:"left",paddingY:56,hidden:false}};
  const {error}=await s.from("page_sections").insert({tenant_id:website.tenant_id,website_id:websiteId,page_id:pageId,section_type:type,variant:"default",draft_variant:"default",sort_order:(last?.sort_order||0)+1,content_json:initial,draft_content_json:initial,responsive_json:responsive,draft_responsive_json:responsive,is_visible:false,draft_is_visible:true,draft_deleted:false});
  if(error)throw new Error(error.message);refresh(websiteId,pageId,website.slug);
}

export async function deleteSection(websiteId:string,pageId:string,sectionId:string){
  const {website}=await requireWebsiteAccess(websiteId);const s=await createClient();
  const {error}=await s.from("page_sections").update({draft_deleted:true,updated_at:new Date().toISOString()}).eq("id",sectionId).eq("website_id",websiteId).eq("page_id",pageId);if(error)throw new Error(error.message);
  refresh(websiteId,pageId,website.slug);
}

export async function moveSection(websiteId:string,pageId:string,sectionId:string,direction:"up"|"down"){
  const {website}=await requireWebsiteAccess(websiteId);const s=await createClient();
  const {data:sections}=await s.from("page_sections").select("id,sort_order").eq("page_id",pageId).eq("draft_deleted",false).order("sort_order");
  const list=sections||[];const idx=list.findIndex((x:any)=>x.id===sectionId);const other=direction==="up"?idx-1:idx+1;
  if(idx<0||other<0||other>=list.length)return;
  const a=list[idx],b=list[other];
  await s.from("page_sections").update({sort_order:b.sort_order}).eq("id",a.id);
  await s.from("page_sections").update({sort_order:a.sort_order}).eq("id",b.id);
  refresh(websiteId,pageId,website.slug);
}

export async function publishPage(websiteId:string,pageId:string){
  const {website,profile}=await requireWebsiteAccess(websiteId);const s=await createClient();
  await publishPageDraft(s,pageId,websiteId,profile.id);
  refresh(websiteId,pageId,website.slug);
}
