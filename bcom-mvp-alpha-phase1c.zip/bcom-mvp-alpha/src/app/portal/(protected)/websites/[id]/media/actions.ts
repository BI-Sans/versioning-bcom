"use server";
import { revalidatePath } from "next/cache";
import { requireWebsiteAccess } from "@/services/auth/guards";
import { uploadTenantImage } from "@/services/media/media.service";

export async function uploadPortalMedia(websiteId:string,fd:FormData){
  const {website,profile}=await requireWebsiteAccess(websiteId);
  const file=fd.get("file");if(!(file instanceof File)||file.size===0)throw new Error("Please select an image.");
  await uploadTenantImage({tenantId:website.tenant_id,websiteId,file,altText:String(fd.get("alt_text")||""),uploadedBy:profile.id});
  revalidatePath(`/portal/websites/${websiteId}/media`);
}
