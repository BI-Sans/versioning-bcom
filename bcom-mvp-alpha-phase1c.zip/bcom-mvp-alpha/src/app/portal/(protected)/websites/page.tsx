import Link from "next/link";
import { requireTenantUser } from "@/services/auth/guards";
import { createClient } from "@/lib/supabase/server";
export const dynamic="force-dynamic";
export default async function PortalWebsites(){const {memberships}=await requireTenantUser();const ids=memberships.map((m:any)=>m.tenant_id);const s=await createClient();const {data}=await s.from("websites").select("id,name,slug,status,tenant_id").in("tenant_id",ids).order("created_at",{ascending:false});return <div><h1 className="text-3xl font-black text-bcom-navy">My Websites</h1><div className="mt-7 grid gap-4 lg:grid-cols-2">{(data??[]).map((w:any)=><Link href={`/portal/websites/${w.id}`} key={w.id} className="card p-5 transition hover:-translate-y-0.5"><div className="font-black text-bcom-navy">{w.name}</div><div className="text-sm text-slate-500">/sites/{w.slug}</div><span className="mt-3 inline-block rounded-full bg-slate-100 px-2 py-1 text-xs">{w.status}</span></Link>)}</div></div>}
