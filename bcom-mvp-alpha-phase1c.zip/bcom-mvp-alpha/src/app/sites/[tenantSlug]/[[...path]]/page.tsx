import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { TenantSiteRenderer } from "@/components/tenant-site-renderer";

export const dynamic = "force-dynamic";

export default async function TenantSite({ params }: { params: Promise<{ tenantSlug: string; path?: string[] }> }) {
  const { tenantSlug, path = [] } = await params;
  const slug = path.join("/");
  const s = await createClient();
  const { data: tenant } = await s.from("tenants").select("id,name,status").eq("slug", tenantSlug).single();
  if (!tenant) notFound();
  if (tenant.status !== "active") return <Unavailable />;

  const { data: web } = await s
    .from("websites")
    .select("id,name,status,brand_kits(*),themes(tokens_json)")
    .eq("tenant_id", tenant.id)
    .eq("status", "active")
    .limit(1)
    .single();
  if (!web) notFound();

  const pageQuery = s.from("pages").select("id,name,slug,status,is_homepage").eq("website_id", web.id).eq("status", "published");
  const { data: page } = slug
    ? await pageQuery.eq("slug", slug).maybeSingle()
    : await pageQuery.eq("is_homepage", true).maybeSingle();
  if (!page) notFound();

  const { data: sections } = await s.from("page_sections").select("id,tenant_id,website_id,page_id,section_type,variant,sort_order,content_json,settings_json,responsive_json,is_visible,created_at,updated_at").eq("page_id", page.id).order("sort_order");
  const brand = web.brand_kits?.[0] || {};
  const tokens = web.themes?.tokens_json || {};
  const primary = brand.primary_color || tokens.colors?.primary || "#091F3B";
  const secondary = brand.secondary_color || tokens.colors?.secondary || "#FCD708";

  return <TenantSiteRenderer sections={(sections || []) as any} primary={primary} secondary={secondary} mode="published" />;
}

function Unavailable() {
  return <main className="flex min-h-screen items-center justify-center bg-slate-50 p-5"><div className="card p-10 text-center"><h1 className="text-3xl font-black text-bcom-navy">Website Temporarily Unavailable</h1><p className="mt-3 text-slate-500">This website is currently inactive.</p></div></main>;
}
