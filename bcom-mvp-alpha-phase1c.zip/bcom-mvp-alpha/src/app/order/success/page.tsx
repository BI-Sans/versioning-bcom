import Link from "next/link";
import { CheckCircle2 } from "lucide-react";

export default async function OrderSuccess({ searchParams }: { searchParams: Promise<{ order?: string }> }) {
  const { order } = await searchParams;
  return <main className="flex min-h-screen items-center justify-center bg-slate-50 p-5"><div className="card max-w-lg p-10 text-center"><CheckCircle2 className="mx-auto h-14 w-14 text-green-600"/><h1 className="mt-5 text-3xl font-black text-bcom-navy">Order Submitted</h1><p className="mt-3 text-slate-600">Order <strong>{order}</strong> berhasil dibuat. B-COM akan melakukan review requirement Anda.</p><p className="mt-2 text-sm text-slate-500">Notifikasi email akan dikirim jika SMTP sudah dikonfigurasi.</p><Link href="/" className="btn-primary mt-7">Kembali ke Home</Link></div></main>;
}
