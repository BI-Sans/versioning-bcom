import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { formatIDR } from "@/lib/utils";
import { submitOrder } from "./actions";

export const dynamic = "force-dynamic";

export default async function OrderPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const supabase = await createClient();
  const { data: pkg } = await supabase.from("packages").select("id,name,slug,short_description,normal_price,promo_price").eq("slug", slug).eq("status", "active").single();
  if (!pkg) notFound();
  const price = Number(pkg.promo_price || pkg.normal_price || 0);
  return (
    <main className="min-h-screen bg-slate-50 py-12">
      <div className="mx-auto grid max-w-5xl gap-6 px-5 lg:grid-cols-[1fr_360px]">
        <form action={submitOrder} className="card p-7 md:p-9">
          <input type="hidden" name="package_id" value={pkg.id} />
          <h1 className="text-3xl font-black text-bcom-navy">Website Requirement Form</h1>
          <p className="mt-2 text-slate-500">Isi data dasar. Detail lanjutan dapat direview bersama Admin B-COM.</p>
          <div className="mt-8 grid gap-5 md:grid-cols-2">
            <div><label className="label">Nama / Company *</label><input className="input" name="customer_name" required /></div>
            <div><label className="label">PIC</label><input className="input" name="pic_name" /></div>
            <div><label className="label">Email *</label><input className="input" type="email" name="customer_email" required /></div>
            <div><label className="label">WhatsApp *</label><input className="input" name="customer_phone" required /></div>
            <div><label className="label">Jenis Usaha</label><input className="input" name="business_type" /></div>
            <div><label className="label">Bahasa</label><select className="input" name="language"><option>Indonesia</option><option>English</option><option>Indonesia + English</option></select></div>
            <div className="md:col-span-2"><label className="label">Referensi website</label><input className="input" name="reference_url" placeholder="https://..." /></div>
            <div className="md:col-span-2"><label className="label">Catatan / kebutuhan khusus</label><textarea className="input min-h-32" name="notes" /></div>
          </div>
          <button className="btn-primary mt-7">Submit Order</button>
        </form>
        <aside className="card h-fit p-6">
          <div className="text-sm text-slate-500">Selected Package</div>
          <h2 className="mt-1 text-xl font-black text-bcom-navy">{pkg.name}</h2>
          <p className="mt-2 text-sm text-slate-500">{pkg.short_description}</p>
          <div className="mt-6 text-3xl font-black text-bcom-navy">{formatIDR(price)}</div>
          <div className="text-xs text-slate-500">belum termasuk PPN</div>
          <div className="mt-6 rounded-xl bg-yellow-50 p-4 text-sm text-slate-700">MVP Alpha menggunakan order submission terlebih dahulu. Payment sandbox akan diaktifkan pada Phase 2.</div>
        </aside>
      </div>
    </main>
  );
}
