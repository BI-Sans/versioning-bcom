"use server";

import { redirect } from "next/navigation";
import { z } from "zod";
import { createAdminClient } from "@/lib/supabase/admin";
import { sendOrderNotification } from "@/services/email/email.service";

const schema = z.object({
  package_id: z.string().uuid(),
  customer_name: z.string().min(2),
  customer_email: z.string().email(),
  customer_phone: z.string().min(6),
  pic_name: z.string().optional(),
  business_type: z.string().optional(),
  language: z.string().optional(),
  reference_url: z.string().optional(),
  notes: z.string().optional()
});

export async function submitOrder(formData: FormData) {
  const parsed = schema.safeParse(Object.fromEntries(formData.entries()));
  if (!parsed.success) throw new Error("Invalid order data");
  const supabase = createAdminClient();
  const { data: pkg, error: pkgError } = await supabase.from("packages").select("*").eq("id", parsed.data.package_id).single();
  if (pkgError || !pkg) throw new Error("Package not found");
  const unitPrice = Number(pkg.promo_price || pkg.normal_price || 0);
  const orderNumber = `BCOM-${new Date().getFullYear()}-${Date.now().toString().slice(-8)}`;
  const { data: order, error } = await supabase.from("orders").insert({
    order_number: orderNumber,
    package_id: pkg.id,
    status: "submitted",
    customer_name: parsed.data.customer_name,
    customer_email: parsed.data.customer_email,
    customer_phone: parsed.data.customer_phone,
    subtotal: unitPrice,
    tax_amount: 0,
    total_amount: unitPrice,
    currency: "IDR",
    package_snapshot_json: { id: pkg.id, name: pkg.name, price: unitPrice, features: pkg.features_json ?? [] },
    requirement_json: parsed.data
  }).select("id,order_number").single();
  if (error || !order) throw new Error(error?.message ?? "Failed creating order");
  await sendOrderNotification({
    orderNumber: order.order_number,
    customerName: parsed.data.customer_name,
    customerEmail: parsed.data.customer_email,
    packageName: pkg.name,
    amount: unitPrice
  });
  redirect(`/order/success?order=${encodeURIComponent(order.order_number)}`);
}
