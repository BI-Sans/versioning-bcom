import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "B-COM | Your Technology Support Partner",
  description: "B-COM technology solutions and software development."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
