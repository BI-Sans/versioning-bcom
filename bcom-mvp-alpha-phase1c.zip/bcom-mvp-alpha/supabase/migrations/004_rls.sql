alter table public.profiles enable row level security;
alter table public.tenants enable row level security;
alter table public.tenant_users enable row level security;
alter table public.website_categories enable row level security;
alter table public.themes enable row level security;
alter table public.websites enable row level security;
alter table public.brand_kits enable row level security;
alter table public.pages enable row level security;
alter table public.page_sections enable row level security;
alter table public.packages enable row level security;
alter table public.orders enable row level security;
alter table public.audit_logs enable row level security;
alter table public.system_settings enable row level security;

create or replace function public.current_profile_id()
returns uuid language sql stable security definer set search_path=public as $$
  select id from public.profiles where auth_user_id = auth.uid() limit 1;
$$;

create or replace function public.is_platform_admin()
returns boolean language sql stable security definer set search_path=public as $$
  select coalesce((select is_platform_admin and status='active' from public.profiles where auth_user_id=auth.uid() limit 1), false);
$$;

create or replace function public.is_tenant_member(target_tenant uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.tenant_users tu join public.profiles p on p.id=tu.user_id where tu.tenant_id=target_tenant and p.auth_user_id=auth.uid() and tu.status='active');
$$;

create policy "public categories read" on public.website_categories for select using (status='active' or public.is_platform_admin());
create policy "public themes read" on public.themes for select using (status='active' or public.is_platform_admin());
create policy "public packages read" on public.packages for select using (status='active' or public.is_platform_admin());

create policy "admin all profiles" on public.profiles for all using (public.is_platform_admin()) with check(public.is_platform_admin());
create policy "own profile read" on public.profiles for select using (auth_user_id=auth.uid());
create policy "admin all tenants" on public.tenants for all using(public.is_platform_admin()) with check(public.is_platform_admin());
create policy "tenant member read tenants" on public.tenants for select using(public.is_tenant_member(id) or status='active');
create policy "admin tenant users" on public.tenant_users for all using(public.is_platform_admin()) with check(public.is_platform_admin());
create policy "tenant member read membership" on public.tenant_users for select using(public.is_tenant_member(tenant_id));
create policy "admin packages write" on public.packages for all using(public.is_platform_admin()) with check(public.is_platform_admin());
create policy "admin orders all" on public.orders for all using(public.is_platform_admin()) with check(public.is_platform_admin());
create policy "admin themes write" on public.themes for all using(public.is_platform_admin()) with check(public.is_platform_admin());
create policy "admin categories write" on public.website_categories for all using(public.is_platform_admin()) with check(public.is_platform_admin());

create policy "website tenant read" on public.websites for select using(public.is_platform_admin() or public.is_tenant_member(tenant_id) or status='active');
create policy "website admin write" on public.websites for all using(public.is_platform_admin() or public.is_tenant_member(tenant_id)) with check(public.is_platform_admin() or public.is_tenant_member(tenant_id));
create policy "brand tenant" on public.brand_kits for all using(public.is_platform_admin() or public.is_tenant_member(tenant_id)) with check(public.is_platform_admin() or public.is_tenant_member(tenant_id));
create policy "brand public active website" on public.brand_kits for select using(exists(select 1 from public.websites w where w.id=website_id and w.status='active'));
create policy "pages public active tenant" on public.pages for select using(public.is_platform_admin() or public.is_tenant_member(tenant_id) or (status='published' and exists(select 1 from public.websites w where w.id=website_id and w.status='active')));
create policy "pages tenant write" on public.pages for all using(public.is_platform_admin() or public.is_tenant_member(tenant_id)) with check(public.is_platform_admin() or public.is_tenant_member(tenant_id));
create policy "sections public tenant" on public.page_sections for select using(public.is_platform_admin() or public.is_tenant_member(tenant_id) or (is_visible=true and exists(select 1 from public.websites w where w.id=website_id and w.status='active')));
create policy "sections tenant write" on public.page_sections for all using(public.is_platform_admin() or public.is_tenant_member(tenant_id)) with check(public.is_platform_admin() or public.is_tenant_member(tenant_id));
create policy "admin audit" on public.audit_logs for select using(public.is_platform_admin());
create policy "admin settings" on public.system_settings for all using(public.is_platform_admin()) with check(public.is_platform_admin());
