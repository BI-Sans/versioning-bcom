create table if not exists public.packages (
  id uuid primary key default gen_random_uuid(), category_id uuid references public.website_categories(id),
  name text not null, slug text unique not null, short_description text, description text,
  pricing_type text not null default 'fixed' check(pricing_type in ('fixed','starting_from','quotation','free')),
  normal_price numeric(14,2) not null default 0, promo_price numeric(14,2), promo_start timestamptz, promo_end timestamptz,
  features_json jsonb not null default '[]'::jsonb, is_featured boolean not null default false,
  show_on_homepage boolean not null default false, status text not null default 'active', sort_order int not null default 0,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(), order_number text unique not null,
  tenant_id uuid references public.tenants(id), package_id uuid references public.packages(id),
  customer_name text not null, customer_email text not null, customer_phone text,
  status text not null default 'submitted', subtotal numeric(14,2) not null default 0,
  discount_amount numeric(14,2) not null default 0, tax_amount numeric(14,2) not null default 0,
  total_amount numeric(14,2) not null default 0, currency text not null default 'IDR',
  package_snapshot_json jsonb not null default '{}'::jsonb, requirement_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(), tenant_id uuid references public.tenants(id), user_id uuid references public.profiles(id),
  action text not null, module text not null, entity_type text, entity_id uuid,
  old_values_json jsonb, new_values_json jsonb, ip_address inet, user_agent text,
  created_at timestamptz not null default now()
);

create table if not exists public.system_settings (
  id uuid primary key default gen_random_uuid(), category text not null, key text unique not null,
  value_json jsonb not null default '{}'::jsonb, is_secret boolean not null default false,
  updated_at timestamptz not null default now(), updated_by uuid references public.profiles(id)
);
