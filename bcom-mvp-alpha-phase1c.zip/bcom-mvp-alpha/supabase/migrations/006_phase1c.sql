-- B-COM MVP Alpha Phase 1C
-- Draft/publish workflow, page versions, account provisioning helpers and Wedding Invitation foundation.

alter table public.page_sections
  add column if not exists draft_variant text,
  add column if not exists draft_content_json jsonb,
  add column if not exists draft_settings_json jsonb,
  add column if not exists draft_responsive_json jsonb,
  add column if not exists draft_is_visible boolean;

update public.page_sections
set
  draft_variant = coalesce(draft_variant, variant),
  draft_content_json = coalesce(draft_content_json, content_json),
  draft_settings_json = coalesce(draft_settings_json, settings_json),
  draft_responsive_json = coalesce(draft_responsive_json, responsive_json),
  draft_is_visible = coalesce(draft_is_visible, is_visible)
where draft_content_json is null
   or draft_variant is null
   or draft_settings_json is null
   or draft_responsive_json is null
   or draft_is_visible is null;

alter table public.page_sections
  alter column draft_variant set default 'default',
  alter column draft_content_json set default '{}'::jsonb,
  alter column draft_settings_json set default '{}'::jsonb,
  alter column draft_responsive_json set default '{}'::jsonb,
  alter column draft_is_visible set default true;

create table if not exists public.page_versions (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  website_id uuid not null references public.websites(id) on delete cascade,
  page_id uuid not null references public.pages(id) on delete cascade,
  version_number integer not null,
  snapshot_json jsonb not null,
  published_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  unique(page_id, version_number)
);

create index if not exists page_versions_page_created_idx on public.page_versions(page_id, created_at desc);

-- Profiles are automatically created for new auth users, including users created from invitation links.
create or replace function public.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
begin
  insert into public.profiles(auth_user_id, full_name, email, status)
  values(new.id, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)), new.email, 'active')
  on conflict(auth_user_id) do update set email=excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_bcom on auth.users;
create trigger on_auth_user_created_bcom
after insert on auth.users
for each row execute function public.handle_new_auth_user();

insert into public.roles(name,scope,description,is_system) values
('Owner','tenant','Full access to the customer tenant',true),
('Admin','tenant','Administrative customer access',true),
('Editor','tenant','Content editing access',true),
('Marketing','tenant','SEO and analytics oriented access',true),
('Viewer','tenant','Read-only customer access',true),
('Super Admin','platform','B-COM platform super administrator',true),
('Admin','platform','B-COM platform administrator',true),
('Designer','platform','B-COM designer',true),
('Support','platform','B-COM support',true),
('Finance','platform','B-COM finance',true)
on conflict(name,scope) do nothing;

-- Wedding Invitation foundation
create table if not exists public.wedding_profiles (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  website_id uuid not null unique references public.websites(id) on delete cascade,
  groom_name text,
  bride_name text,
  wedding_date date,
  story_text text,
  music_url text,
  gift_settings_json jsonb not null default '{}'::jsonb,
  settings_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.wedding_events (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  website_id uuid not null references public.websites(id) on delete cascade,
  name text not null,
  event_date date,
  start_time time,
  end_time time,
  venue_name text,
  address text,
  maps_url text,
  streaming_url text,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.wedding_guests (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  website_id uuid not null references public.websites(id) on delete cascade,
  name text not null,
  phone text,
  guest_group text,
  slug text not null,
  access_token uuid not null default gen_random_uuid(),
  invitation_status text not null default 'not_sent' check(invitation_status in ('not_sent','sent','opened')),
  opened_at timestamptz,
  rsvp_status text check(rsvp_status in ('yes','no','maybe')),
  number_of_guests integer not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(website_id, slug)
);

create table if not exists public.wedding_message_templates (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  website_id uuid not null references public.websites(id) on delete cascade,
  name text not null,
  template_type text not null default 'custom',
  message_template text not null,
  is_default boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.wedding_rsvps (
  id uuid primary key default gen_random_uuid(),
  guest_id uuid not null references public.wedding_guests(id) on delete cascade,
  website_id uuid not null references public.websites(id) on delete cascade,
  status text not null check(status in ('yes','no','maybe')),
  guest_count integer not null default 1,
  message text,
  submitted_at timestamptz not null default now()
);

create table if not exists public.wedding_guestbook (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  website_id uuid not null references public.websites(id) on delete cascade,
  guest_id uuid references public.wedding_guests(id) on delete set null,
  name text not null,
  message text not null,
  is_approved boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.page_versions enable row level security;
alter table public.wedding_profiles enable row level security;
alter table public.wedding_events enable row level security;
alter table public.wedding_guests enable row level security;
alter table public.wedding_message_templates enable row level security;
alter table public.wedding_rsvps enable row level security;
alter table public.wedding_guestbook enable row level security;

create policy "page versions tenant read" on public.page_versions for select
using(public.is_platform_admin() or public.is_tenant_member(tenant_id));
create policy "page versions tenant insert" on public.page_versions for insert
with check(public.is_platform_admin() or public.is_tenant_member(tenant_id));

create policy "wedding profile tenant" on public.wedding_profiles for all
using(public.is_platform_admin() or public.is_tenant_member(tenant_id))
with check(public.is_platform_admin() or public.is_tenant_member(tenant_id));
create policy "wedding profile public" on public.wedding_profiles for select
using(exists(select 1 from public.websites w where w.id=website_id and w.status='active'));

create policy "wedding events tenant" on public.wedding_events for all
using(public.is_platform_admin() or public.is_tenant_member(tenant_id))
with check(public.is_platform_admin() or public.is_tenant_member(tenant_id));
create policy "wedding events public" on public.wedding_events for select
using(exists(select 1 from public.websites w where w.id=website_id and w.status='active'));

create policy "wedding guests tenant" on public.wedding_guests for all
using(public.is_platform_admin() or public.is_tenant_member(tenant_id))
with check(public.is_platform_admin() or public.is_tenant_member(tenant_id));
-- Public guest lookup is intentionally not opened through RLS. The invitation route uses the server admin client + token.

create policy "wedding templates tenant" on public.wedding_message_templates for all
using(public.is_platform_admin() or public.is_tenant_member(tenant_id))
with check(public.is_platform_admin() or public.is_tenant_member(tenant_id));

create policy "wedding rsvp tenant read" on public.wedding_rsvps for select
using(public.is_platform_admin() or exists(select 1 from public.wedding_guests g where g.id=guest_id and public.is_tenant_member(g.tenant_id)));

create policy "wedding guestbook tenant" on public.wedding_guestbook for all
using(public.is_platform_admin() or public.is_tenant_member(tenant_id))
with check(public.is_platform_admin() or public.is_tenant_member(tenant_id));
create policy "wedding guestbook public read" on public.wedding_guestbook for select
using(is_approved=true and exists(select 1 from public.websites w where w.id=website_id and w.status='active'));

alter table public.page_sections add column if not exists draft_deleted boolean not null default false;

-- Prevent anonymous API callers from reading unpublished draft columns directly.
revoke select on public.page_sections from anon;
grant select (id,tenant_id,website_id,page_id,section_type,variant,sort_order,content_json,settings_json,responsive_json,is_visible,created_at,updated_at) on public.page_sections to anon;
