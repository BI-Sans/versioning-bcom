create table if not exists public.website_categories (
  id uuid primary key default gen_random_uuid(), name text not null, slug text unique not null,
  description text, icon text, status text not null default 'active', sort_order int not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.themes (
  id uuid primary key default gen_random_uuid(), category_id uuid references public.website_categories(id) on delete set null,
  name text not null, slug text unique not null, description text, thumbnail_url text,
  status text not null default 'active', is_premium boolean not null default false,
  tokens_json jsonb not null default '{}'::jsonb, version int not null default 1,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.websites (
  id uuid primary key default gen_random_uuid(), tenant_id uuid not null references public.tenants(id) on delete cascade,
  name text not null, slug text unique not null, category_id uuid references public.website_categories(id),
  theme_id uuid references public.themes(id), status text not null default 'draft' check(status in ('draft','provisioning','active','maintenance','suspended','archived')),
  default_language text not null default 'id', published_at timestamptz, deleted_at timestamptz,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.brand_kits (
  id uuid primary key default gen_random_uuid(), tenant_id uuid not null references public.tenants(id) on delete cascade,
  website_id uuid not null references public.websites(id) on delete cascade,
  logo_url text, favicon_url text, primary_color text default '#091F3B', secondary_color text default '#FCD708', accent_color text,
  heading_font text default 'Manrope', body_font text default 'Inter', settings_json jsonb not null default '{}'::jsonb,
  unique(website_id)
);

create table if not exists public.pages (
  id uuid primary key default gen_random_uuid(), tenant_id uuid not null references public.tenants(id) on delete cascade,
  website_id uuid not null references public.websites(id) on delete cascade,
  name text not null, slug text not null default '', page_type text not null default 'standard', status text not null default 'draft',
  sort_order int not null default 0, is_homepage boolean not null default false, published_at timestamptz,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique(website_id,slug)
);

create table if not exists public.page_sections (
  id uuid primary key default gen_random_uuid(), tenant_id uuid not null references public.tenants(id) on delete cascade,
  website_id uuid not null references public.websites(id) on delete cascade, page_id uuid not null references public.pages(id) on delete cascade,
  section_type text not null, variant text not null default 'default', sort_order int not null default 0,
  content_json jsonb not null default '{}'::jsonb, settings_json jsonb not null default '{}'::jsonb,
  responsive_json jsonb not null default '{}'::jsonb, is_visible boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
