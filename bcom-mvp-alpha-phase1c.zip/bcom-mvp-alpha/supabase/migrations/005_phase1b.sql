create table if not exists public.media (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  website_id uuid not null references public.websites(id) on delete cascade,
  file_name text not null,
  file_path text not null,
  public_url text,
  file_type text,
  mime_type text,
  file_size bigint,
  alt_text text,
  uploaded_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.landing_sections (
  id uuid primary key default gen_random_uuid(),
  section_key text unique not null,
  section_type text not null,
  variant text not null default 'default',
  sort_order int not null default 0,
  content_json jsonb not null default '{}'::jsonb,
  settings_json jsonb not null default '{}'::jsonb,
  is_visible boolean not null default true,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.media enable row level security;
alter table public.landing_sections enable row level security;

create policy "media tenant read" on public.media for select
using (public.is_platform_admin() or public.is_tenant_member(tenant_id));

create policy "media tenant write" on public.media for all
using (public.is_platform_admin() or public.is_tenant_member(tenant_id))
with check (public.is_platform_admin() or public.is_tenant_member(tenant_id));

create policy "landing public read" on public.landing_sections for select
using (is_visible = true or public.is_platform_admin());

create policy "landing admin write" on public.landing_sections for all
using (public.is_platform_admin()) with check (public.is_platform_admin());

insert into storage.buckets (id, name, public)
values ('tenant-assets', 'tenant-assets', true)
on conflict (id) do update set public = true;

insert into public.landing_sections(section_key,section_type,variant,sort_order,content_json,is_visible,published_at)
values
('announcement','announcement','default',1,'{"text":"Established in 2022"}'::jsonb,true,now()),
('hero','hero','split-right',2,'{"eyebrow":"Technology Solutions","title":"Build. Manage. Grow with Technology.","description":"B-COM membantu bisnis membangun website, custom web application, business management system, automation, dan solusi software yang praktis dengan dukungan berkelanjutan.","primary_cta":"Lihat Paket","secondary_cta":"Konsultasi"}'::jsonb,true,now()),
('services','services','grid',3,'{"eyebrow":"Our Services","title":"Technology solutions that support your business.","items":["Website Development","Custom Web Application","Business Management System","Maintenance & Support","Dashboard & Internal Tools","Automation Solutions","Backend & Database","Deployment & Cloud Setup"]}'::jsonb,true,now()),
('about','about','split',5,'{"eyebrow":"About B-COM","title":"Your Technology Support Partner.","description":"B-COM (Bekasi Computer) adalah technology solutions partner yang berfokus pada software & web technology solutions.","location":"Bekasi, West Java, Indonesia"}'::jsonb,true,now())
on conflict (section_key) do nothing;
