insert into public.website_categories (name,slug,description,sort_order) values
('Landing Page','landing-page','Single page marketing site',1),
('Company Profile','company-profile','Multi page corporate website',2),
('Portfolio','portfolio','Personal and professional portfolio',3),
('Restaurant / Cafe','restaurant-cafe','Restaurant and cafe website',4),
('Travel','travel','Travel packages and destinations',5),
('Product Catalog','product-catalog','Product catalog and inquiry website',6),
('Professional Services','professional-services','Professional service business',7),
('Wedding Invitation','wedding-invitation','Digital wedding invitation',8),
('Custom','custom','Custom web application',9)
on conflict (slug) do nothing;

insert into public.themes(category_id,name,slug,description,tokens_json)
select id,'Portfolio Modern','portfolio-modern','Clean modern portfolio', '{"colors":{"primary":"#091F3B","secondary":"#FCD708"},"typography":{"heading":"Manrope","body":"Inter"}}'::jsonb from public.website_categories where slug='portfolio'
on conflict(slug) do nothing;

insert into public.themes(category_id,name,slug,description,tokens_json)
select id,'Floral Romantic','floral-romantic','Soft wedding invitation theme', '{"colors":{"primary":"#7C4A5D","secondary":"#EFD6DE"}}'::jsonb from public.website_categories where slug='wedding-invitation'
on conflict(slug) do nothing;

insert into public.packages(category_id,name,slug,short_description,pricing_type,normal_price,promo_price,is_featured,show_on_homepage,status,sort_order,features_json)
select id,'Website Portfolio','website-portfolio','Website portfolio responsive untuk personal branding, freelancer, creator, dan profesional.','fixed',500000,200000,true,true,'active',1,'["Responsive","SEO Basic","Portfolio Gallery","Contact Form","B-COM Subdomain"]'::jsonb from public.website_categories where slug='portfolio'
on conflict(slug) do update set normal_price=excluded.normal_price,promo_price=excluded.promo_price,show_on_homepage=true;

insert into public.packages(category_id,name,slug,short_description,pricing_type,normal_price,is_featured,show_on_homepage,status,sort_order,features_json)
select id,'Company Profile','company-profile-basic','Website company profile profesional dan responsive.','starting_from',1500000,false,true,'active',2,'["Multi Page","Responsive","Contact Form","SEO Basic"]'::jsonb from public.website_categories where slug='company-profile'
on conflict(slug) do nothing;

insert into public.packages(category_id,name,slug,short_description,pricing_type,normal_price,is_featured,show_on_homepage,status,sort_order,features_json)
select id,'Wedding Invitation','wedding-invitation-basic','Undangan digital dengan RSVP, guestbook, guest management, dan personalized link.','fixed',150000,false,true,'active',3,'["Responsive Invitation","Countdown","RSVP","Guestbook","Personalized Guest Link","Message Generator"]'::jsonb from public.website_categories where slug='wedding-invitation'
on conflict(slug) do nothing;
