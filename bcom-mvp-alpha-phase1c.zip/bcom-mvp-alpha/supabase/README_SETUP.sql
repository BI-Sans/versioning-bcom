-- 1. Jalankan migration 001 sampai 004 dari Supabase SQL Editor jika tidak memakai Supabase CLI.
-- 2. Jalankan seed.sql.
-- 3. Buat user admin di Supabase Authentication > Users.
-- 4. Setelah user dibuat, jalankan query ini dan ganti email:

insert into public.profiles (auth_user_id,full_name,email,is_platform_admin,status)
select id,'B-COM Super Admin',email,true,'active'
from auth.users
where email='YOUR_ADMIN_EMAIL@example.com'
on conflict(auth_user_id) do update set is_platform_admin=true,status='active';
